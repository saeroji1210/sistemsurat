# Panduan Memasang Sistem Persuratan (untuk pemula)

Isi paket: `Kode.gs` + `appsscript.json` (backend Google Apps Script) dan `index.html`, `style.css`, `js/config.js`, `js/app.js` (frontend untuk GitHub Pages).
Kerjakan berurutan. Total sekitar 30–45 menit. Gunakan **satu akun Google pemilik** (disebut "akun pemilik") untuk langkah 1–4.

## Langkah 1 — Siapkan Backend (Apps Script)
1. Buka https://script.google.com → **Proyek baru** → beri nama `Sistem Persuratan`.
2. Hapus isi `Code.gs`, lalu tempel seluruh isi **Kode.gs** dari paket ini. (Nama file boleh tetap `Code.gs`.)
3. Klik ikon ⚙ **Project Settings** → centang **Show "appsscript.json" manifest file in editor**. Buka file `appsscript.json` di editor, ganti isinya dengan isi `appsscript.json` dari paket. Simpan.
4. Di editor, pilih fungsi **`setupAppEnvironment`** pada menu fungsi di atas → klik **Run**. Setujui izin yang diminta (Drive, Sheets, Docs, Mail, Eksternal). Jika muncul "Google hasn't verified this app" → *Advanced* → *Go to … (unsafe)*: ini aman karena skrip milik Anda sendiri.
5. Buka **Execution log**. Catat baris **AKSES DARURAT** (username `darurat` + sandi). Sandi ini **hanya tampil sekali**; simpan di tempat aman. Jika hilang, jalankan fungsi `resetAksesDarurat`.
6. Setup otomatis membuat: folder "Sistem Persuratan" di Drive, spreadsheet database (8 sheet), 4 subfolder, dan **contoh template Surat Tugas** di Google Docs.

## Langkah 2 — Buat Google Client ID (untuk tombol "Masuk dengan Google")
1. Buka https://console.cloud.google.com → buat proyek baru (atau pakai yang ada).
2. **APIs & Services → OAuth consent screen**: pilih *External* (atau *Internal* bila Anda memakai Google Workspace organisasi), isi nama aplikasi dan email, simpan. Jika *External* masih berstatus Testing, tambahkan email pengguna uji di *Test users*, atau klik *Publish app*.
3. **Credentials → Create credentials → OAuth client ID** → jenis **Web application**.
4. Pada **Authorized JavaScript origins** isi alamat GitHub Pages Anda **tanpa garis miring dan tanpa folder**, contoh: `https://usernameanda.github.io`. (Boleh tambah `http://localhost:5500` bila ingin mencoba di komputer.)
5. Simpan, lalu salin **Client ID** (berakhiran `.apps.googleusercontent.com`).

## Langkah 3 — Isi Script Properties
Di Apps Script: ⚙ **Project Settings → Script Properties → Edit script properties**. Isi/ubah nilai berikut (nama harus persis):

| Properti | Isi | Keterangan |
|---|---|---|
| `GOOGLE_CLIENT_ID` | Client ID dari Langkah 2 | wajib |
| `ADMIN_EMAILS` | `emailanda@gmail.com` (pisahkan koma bila lebih dari satu) | admin tidak perlu didaftarkan di sheet |
| `DOMAIN_IZIN` | mis. `kampusanda.ac.id` | akun domain ini otomatis aktif sebagai Pemohon. Kosongkan bila tidak ada |
| `FRONTEND_URL` | `https://usernameanda.github.io/nama-repo/` | alamat lengkap aplikasi; dipakai untuk tautan QR |
| `NAMA_ORG` | nama organisasi Anda | tampil di aplikasi & halaman verifikasi |
| `MODE_AKSES` | `GMAIL` (bawaan) | `GMAIL`: domain otomatis aktif, Gmail umum menunggu persetujuan admin. Alternatif: `INSTITUSI`, `WHITELIST`, `CAMPURAN` |
| `DAFTAR_MANDIRI` | `true` | `false` = Gmail umum ditolak total |

**Jangan pernah** mengisi properti lain yang dibuat otomatis (`SESSION_SECRET`, `HMAC_KEY`, `EMERGENCY_*`, `CRED_*`). Jangan membagikan isi Script Properties kepada siapa pun.

Lalu jalankan fungsi **`pasangTrigger`** satu kali (menjaga server tetap hangat & mengirim email notifikasi).

## Langkah 4 — Deploy backend
1. **Deploy → New deployment → ⚙ Web app**.
2. *Execute as*: **Me**. *Who has access*: **Anyone**. Klik **Deploy**.
3. Salin **Web app URL** (berakhiran `/exec`).
> Setiap Anda mengubah `Kode.gs`, pilih **Deploy → Manage deployments → ✏ → Version: New version → Deploy**. URL tetap sama.

## Langkah 5 — Pasang Frontend di GitHub Pages
1. Buka `js/config.js`, ganti `GANTI_DENGAN_ID_DEPLOYMENT_ANDA` hingga seluruh `GAS_URL` = URL `/exec` dari Langkah 4. **Hanya** baris ini yang perlu diisi.
2. Buat repositori GitHub baru (public). Upload `index.html`, `style.css`, dan folder `js` (berisi `config.js` dan `app.js`) — via tombol **Add file → Upload files**.
3. **Settings → Pages → Branch: main / (root) → Save.** Tunggu 1–2 menit hingga alamatnya aktif.
4. Pastikan alamat itu sama dengan `FRONTEND_URL` (Langkah 3) dan origin di Langkah 2.

## Langkah 6 — Konfigurasi pertama (lewat aplikasi)
1. Buka alamat aplikasi → **Masuk dengan Akun Google** memakai email yang ada di `ADMIN_EMAILS`.
2. **Kelola Pengguna**: tambahkan/setujui pengguna. Ubah akun pimpinan menjadi peran **Pimpinan**. Isi **NIP** bila akan memakai login NIP, lalu klik ikon kunci 🔑 untuk membuat sandi sementara (tampil sekali).
3. **Template → bagian Pejabat → Tambah / Ubah Pejabat**: pilih akun pimpinan, isi jabatan & NIP, centang jenis surat yang boleh ditandatangani, **unggah gambar tanda tangan (PNG transparan)** dan stempel (PNG).
4. **Template → Surat Tugas**: pilih **pejabat penandatangan utama**, simpan.
5. Buka Google Docs master (tombol/ID di editor template; ada di folder *Template Kop Surat*). **Ganti baris "[GANTI DENGAN KOP SURAT…]" dengan kop organisasi Anda.** Pertahankan penanda `{{…}}`.
6. **Uji alur lengkap**: Ajukan Surat (sebagai pemohon) → Kelola Surat → **Proses** → *Beri Nomor & Kirim ke Pimpinan* → masuk sebagai pimpinan → **Verifikasi Surat** → *Setujui & Bubuhkan TTE* → unduh PDF → pindai QR / **Cek Keaslian Surat**.

## Aturan menulis template Google Docs
- Penanda memakai dua kurung kurawal: `{{perihal}}`, `{{nama_personel}}`, `{{tanggal_mulai}}`, dst. Klik **Deteksi penanda** di editor template agar daftar isian dibuat otomatis, lalu atur tipenya.
- Penanda otomatis sistem: `{{nomor_surat}} {{tanggal_terbit}} {{nama_pejabat}} {{jabatan_pejabat}} {{nip_pejabat}} {{ttd}} {{cap}} {{qr}} {{kode_verifikasi}} {{nama_pemohon}} {{unit_pemohon}}`.
- Tipe **personel**: `{{nama_personel}}` = nama, tambahan `{{nama_personel_nip}}`, `{{nama_personel_jabatan}}`, `{{nama_personel_unit}}`. Tipe **instansi**: `{{x}}` = nama, `{{x_alamat}}`.
- Letakkan `{{ttd}}`, `{{cap}}`, dan `{{qr}}` pada paragraf masing-masing (atau sel tabel) dan beri ruang kosong secukupnya.

## Keamanan — yang perlu Anda tahu
- Sandi NIP **tidak** disimpan di Sheet atau kode; hanya hash+salt di Script Properties. Gagal login 5× mengunci NIP 15 menit.
- Batasi siapa yang punya akses **edit** ke proyek Apps Script, spreadsheet, dan folder Drive. Pemilik skrip dapat membaca semua data.
- Gambar tanda tangan/cap disimpan di folder privat dan hanya dibubuhkan saat pimpinan menyetujui.
- QR dibuat lewat layanan `api.qrserver.com` (pihak ketiga). Layanan itu hanya menerima tautan verifikasi yang memang publik. Jika ingin menghapus ketergantungan ini, QR dapat diganti dengan pembuat QR lokal.
- Kekuatan hukum: tanda tangan di sini berupa gambar tanda tangan yang dibubuhkan otomatis plus QR/HMAC. Ini **bukan** tanda tangan elektronik tersertifikasi (mis. BSrE). Konfirmasikan penerimaannya ke bagian hukum organisasi Anda.
- Email notifikasi memakai kuota Gmail (±100/hari untuk akun biasa, ±1.500 untuk Workspace). Matikan dengan `NOTIF_EMAIL_AKTIF = false`.

## Jika ada masalah
| Gejala | Penyebab umum |
|---|---|
| Tombol Google tidak muncul / "Login Google belum dikonfigurasi" | `GOOGLE_CLIENT_ID` kosong, atau origin GitHub Pages belum didaftarkan di Langkah 2 |
| "Tidak dapat terhubung ke server" | `GAS_URL` salah, atau deployment belum "Anyone" |
| "Server belum disiapkan" | `setupAppEnvironment` belum dijalankan |
| Setelah mengubah kode tidak ada perubahan | Belum membuat **New version** pada Manage deployments |
| "Dokumen Google Docs tidak bisa dibuka" | Docs master bukan milik/tidak dapat diakses akun pemilik skrip |
| "TTD pejabat belum diunggah" | Lengkapi di Template → Pejabat |
| "FRONTEND_URL belum diisi" | Isi Script Properties (Langkah 3) |
| Akun Gmail "menunggu persetujuan" | Setujui di Kelola Pengguna |
