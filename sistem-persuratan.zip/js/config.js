// Satu-satunya konfigurasi frontend. TIDAK boleh berisi rahasia.
// Ganti dengan URL Web App Anda (berakhiran /exec) setelah deploy Apps Script.
const GAS_URL = 'https://script.google.com/macros/s/GANTI_DENGAN_ID_DEPLOYMENT_ANDA/exec';
