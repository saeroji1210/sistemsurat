/**
 * ============================================================
 *  SISTEM PERSURATAN — Backend REST API (Google Apps Script)
 *  Mode B: Login Google (ID token) + NIP/sandi, token sesi HMAC
 *  Deploy: Execute as = Me | Who has access = Anyone
 *  Semua rahasia ada di Script Properties (bukan di kode ini).
 * ============================================================
 */
const APP_VERSION = '1.0.0';

// ---------- Konfigurasi struktur sheet ----------
const KOLOM = {
  Pengguna:   ['email', 'role', 'status', 'tanggal', 'nama', 'unit', 'nip', 'jabatan', 'diubah'],
  Pejabat:    ['email', 'nama', 'jabatan', 'nip', 'id_ttd', 'id_cap', 'jenis_diizinkan'],
  Template:   ['kode', 'nama', 'id_docs', 'isian', 'format_nomor', 'reset_nomor', 'pejabat_email', 'boleh_pemohon', 'aktif', 'mulai_nomor', 'deskripsi'],
  Nomor:      ['jenis', 'periode', 'terakhir'],
  Pengajuan:  ['id', 'tanggal', 'jenis', 'email_pemohon', 'data', 'status', 'nomor_surat', 'status_nomor', 'id_pdf', 'id_pdf_pratinjau', 'kode_verif', 'email_pemverifikasi', 'waktu_verifikasi', 'catatan_penolakan', 'catatan_admin', 'tanggal_terbit', 'id_lampiran', 'pejabat_email', 'tgl_surat'],
  Log:        ['waktu', 'email', 'aksi', 'id_pengajuan', 'detail'],
  Instansi:   ['id', 'nama', 'jenis', 'alamat', 'kontak', 'email', 'aktif'],
  SuratMasuk: ['id', 'no_agenda', 'no_surat_asal', 'tgl_surat', 'tgl_terima', 'instansi_id', 'perihal', 'sifat', 'id_lampiran', 'status', 'tujuan_disposisi', 'catatan_disposisi', 'dicatat_oleh', 'dicatat_pada']
};
const ROLES = ['ADMIN', 'PIMPINAN', 'USER'];
const STATUS_SURAT = ['DIAJUKAN', 'DIPROSES', 'MENUNGGU_VERIFIKASI', 'TERBIT', 'DITOLAK', 'DIBATALKAN'];
const BULAN_ID = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
const ROMAWI = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
const TAG_SISTEM = ['nomor_surat', 'tanggal_terbit', 'nama_pejabat', 'jabatan_pejabat', 'nip_pejabat', 'kode_verifikasi', 'nama_pemohon', 'unit_pemohon', 'ttd', 'cap', 'qr'];
const LAMPIRAN_MAKS = 5 * 1024 * 1024;
const MIME_LAMPIRAN = ['application/pdf', 'image/png', 'image/jpeg'];

// ============================================================
// 1. ROUTER (satu doGet + satu doPost) & TELEMETRI
// ============================================================
function doGet(e) { return doRequest_(e, 'GET'); }
function doPost(e) { return doRequest_(e, 'POST'); }

function doRequest_(e, metode) {
  const t0 = Date.now();
  let body = {}, res;
  try {
    if (metode === 'GET') body = Object.assign({}, e.parameter || {});
    else body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    res = dispatch(body, metode);
  } catch (err) {
    res = fail(err && err.message ? err.message : String(err));
  }
  res.ms = Date.now() - t0;
  res.v = APP_VERSION;
  if (res.ms > 4000) queueLog('-', 'SYSTEM', 'SLOW', (body.action || '') + ' ' + res.ms + ' ms', '');
  return buildResponse(res);
}

function dispatch(b, metode) {
  const action = b.action || 'ping';
  switch (action) {
    // --- publik ---
    case 'ping':                  return { success: true, pong: true };
    case 'getAuthConfig':         return getAuthConfig_();
    case 'getVerifikasiPublik':   return getVerifikasiPublik_(b.id, b.k);
    case 'login':                 return loginDenganGoogle(b.idToken);
    case 'loginNip':              return loginNip_(b.nip, b.sandi);
    case 'batch':                 return batchRun_(b.calls);
    // --- semua peran aktif ---
    case 'boot':                  return bootData(b.token);
    case 'getDashboard':          return getDashboard_(b);
    case 'ubahSandi':             return ubahSandi_(b);
    case 'ajukan':                return ajukan_(b);
    case 'listRiwayat':           return listRiwayat_(b);
    case 'getPengajuan':          return getPengajuan_(b);
    case 'fetchPdf':              return fetchPdf_(b);
    case 'fetchLampiranPengajuan': return fetchLampiranPengajuan_(b);
    case 'listArsip':             return listArsip_(b);
    case 'listInstansi':          return listInstansi_(b);
    case 'listPersonel':          return listPersonel_(b);
    // --- admin: surat ---
    case 'listAntreanKelola':     return listAntreanKelola_(b);
    case 'simpanPerbaikan':       return simpanPerbaikan_(b);
    case 'prosesDanNomori':       return prosesDanNomori_(b);
    case 'tolakAdmin':            return tolakAdmin_(b);
    case 'batalkanSurat':         return batalkanSurat_(b);
    case 'buatLangsung':          return buatLangsung_(b);
    case 'listNomor':             return listNomor_(b);
    // --- pimpinan ---
    case 'listAntreanVerifikasi': return listAntreanVerifikasi_(b);
    case 'setujuiTTE':            return setujuiTTE_(b);
    case 'tolakPimpinan':         return tolakPimpinan_(b);
    // --- admin: master ---
    case 'listTemplate':          return listTemplate_(b);
    case 'getPenandaDocs':        return getPenandaDocs_(b);
    case 'simpanTemplate':        return simpanTemplate_(b);
    case 'listPejabat':           return listPejabat_(b);
    case 'simpanPejabat':         return simpanPejabat_(b);
    case 'listPengguna':          return listPengguna_(b);
    case 'tambahPengguna':        return tambahPengguna_(b);
    case 'ubahPengguna':          return ubahPengguna_(b);
    case 'aturSandi':             return aturSandi_(b);
    case 'listLog':               return listLog_(b);
    case 'getLaporan':            return getLaporan_(b);
    case 'simpanInstansi':        return simpanInstansi_(b);
    // --- surat masuk ---
    case 'listSuratMasuk':        return listSuratMasuk_(b);
    case 'catatSuratMasuk':       return catatSuratMasuk_(b);
    case 'disposisiSuratMasuk':   return disposisiSuratMasuk_(b);
    case 'selesaiSuratMasuk':     return selesaiSuratMasuk_(b);
    case 'fetchLampiranMasuk':    return fetchLampiranMasuk_(b);
    default:                      return fail('ACTION_TIDAK_DIKENAL');
  }
}

function fail(pesan) { return { success: false, message: pesan }; }
function ok_(obj) { return Object.assign({ success: true }, obj || {}); }
function buildResponse(data) {
  return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}

// ---- Log sistem ringan (tidak pernah menggagalkan respons) ----
function queueLog(user, kategori, jenis, detail, ref) {
  try {
    const d = typeof detail === 'object' ? JSON.stringify(redaksi_(detail)) : String(detail || '');
    Logger.log('[' + kategori + '/' + jenis + '] ' + user + ' ' + d + ' ' + (ref || ''));
  } catch (e) { /* abaikan */ }
}

// ---- Batch: hanya aksi BACA, tiap item membawa token sendiri ----
const BATCH_MAKS = 20;
function batchRun_(calls) {
  if (!Array.isArray(calls) || !calls.length || calls.length > BATCH_MAKS) return fail('BATCH_TIDAK_VALID');
  const results = calls.map(function (c) {
    if (!c || !/^(get|list|fetch|read|boot|ping)/i.test(String(c.action || ''))) return fail('BATCH_HANYA_BACA');
    try { return dispatch(Object.assign({}, c), 'GET'); }
    catch (e) { return fail(e && e.message ? e.message : String(e)); }
  });
  return { success: true, results: results };
}

// ---- Warmup & trigger ----
function warmup() {
  try { tabelC_('Pengguna'); tabelC_('Template'); tabelC_('Pejabat'); tabelC_('Instansi'); } catch (e) { /* abaikan */ }
}
function pasangTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    const f = t.getHandlerFunction();
    if (f === 'warmup' || f === 'kirimNotifTerjadwal') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('warmup').timeBased().everyMinutes(5).create();
  ScriptApp.newTrigger('kirimNotifTerjadwal').timeBased().everyMinutes(5).create();
  Logger.log('✅ Trigger warmup & notifikasi email dipasang (tiap 5 menit).');
}

// ============================================================
// 2. SCRIPT PROPERTIES, KRIPTOGRAFI, SESI (rahasia R1–R10)
// ============================================================
const PROPS = PropertiesService.getScriptProperties();
let _PROP_MEMO = null;
function prop_(key, def) {
  if (!_PROP_MEMO) _PROP_MEMO = PROPS.getProperties();
  const v = _PROP_MEMO[key];
  return v === undefined || v === null || v === '' ? (def === undefined ? '' : def) : v;
}
function setProp_(key, val) { PROPS.setProperty(key, String(val)); if (_PROP_MEMO) _PROP_MEMO[key] = String(val); }
function setProps_(obj) { PROPS.setProperties(obj); if (_PROP_MEMO) Object.keys(obj).forEach(function (k) { _PROP_MEMO[k] = String(obj[k]); }); }
function delProp_(key) { PROPS.deleteProperty(key); if (_PROP_MEMO) delete _PROP_MEMO[key]; }

function acak_(n, huruf) {
  huruf = huruf || 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
  let s = '';
  while (s.length < n) {
    Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, Utilities.getUuid()).forEach(function (b) {
      if (s.length < n) s += huruf[(b & 0xff) % huruf.length];
    });
  }
  return s;
}
function sandiAcak_(n) { const s = acak_(n || 16); return /\d/.test(s) && /[A-Za-z]/.test(s) ? s : sandiAcak_(n); }
function hashPass_(pass, salt) {
  let h = String(pass);
  for (let i = 0; i < 300; i++) h = Utilities.base64Encode(Utilities.computeHmacSha256Signature(h + salt, salt));
  return h;
}
function samaAman_(a, b) {
  a = String(a); b = String(b);
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
function samarkan_(v) { v = String(v || ''); return !v ? '' : v.length <= 8 ? '••••••' : v.slice(0, 4) + '••••••' + v.slice(-3); }

const SESI_JAM = 12;
function secret_() {
  let s = prop_('SESSION_SECRET');
  if (!s) { s = acak_(64); setProp_('SESSION_SECRET', s); }
  return s;
}
function hmac_(s) { return Utilities.base64EncodeWebSafe(Utilities.computeHmacSha256Signature(s, secret_())).replace(/=+$/, ''); }
function signToken_(p) {
  const body = Utilities.base64EncodeWebSafe(JSON.stringify(p)).replace(/=+$/, '');
  return body + '.' + hmac_(body);
}
// w = wajib ganti sandi (sesi terbatas)
function buatSesi_(email, role, nama, darurat, wajibGanti) {
  const now = Date.now();
  return signToken_({ e: email, r: role, n: nama || '', i: now, x: now + SESI_JAM * 3600e3, d: darurat ? 1 : 0, w: wajibGanti ? 1 : 0 });
}
function verifyToken_(t) {
  try {
    const parts = String(t || '').split('.');
    if (parts.length !== 2 || !samaAman_(hmac_(parts[0]), parts[1])) return null;
    let b = parts[0]; while (b.length % 4) b += '=';
    const p = JSON.parse(Utilities.newBlob(Utilities.base64DecodeWebSafe(b)).getDataAsString());
    if (!p.x || p.x < Date.now()) return null;
    const rev = Number(CacheService.getScriptCache().get('rev_' + p.e) || prop_('REV_' + p.e) || 0);
    if (p.i < rev) return null;
    return { email: p.e, role: p.r, nama: p.n || '', exp: p.x, darurat: !!p.d, wajibGanti: !!p.w };
  } catch (e) { return null; }
}
function revokeAll_(email) {
  const t = String(Date.now());
  setProp_('REV_' + email, t);
  CacheService.getScriptCache().put('rev_' + email, t, 21600);
}
function rotasiSecretSesi() { setProp_('SESSION_SECRET', acak_(64)); Logger.log('✅ SESSION_SECRET dirotasi — semua sesi berakhir.'); }

function setupRahasia_() {
  secret_();
  if (!prop_('HMAC_KEY')) setProp_('HMAC_KEY', acak_(48));
  if (!prop_('EMERGENCY_PASS_HASH')) {
    const sandi = sandiAcak_(16), salt = Utilities.getUuid();
    setProps_({ EMERGENCY_USER: 'darurat', EMERGENCY_SALT: salt, EMERGENCY_PASS_HASH: hashPass_(sandi, salt) });
    Logger.log('🔐 AKSES DARURAT (catat sekarang, hanya tampil sekali): username = darurat | sandi = ' + sandi);
  }
}
function resetAksesDarurat() {
  const p = sandiAcak_(16), salt = Utilities.getUuid();
  setProps_({ EMERGENCY_USER: 'darurat', EMERGENCY_SALT: salt, EMERGENCY_PASS_HASH: hashPass_(p, salt) });
  delProp_('KUNCI_darurat');
  revokeAll_('darurat');
  Logger.log('🔐 Akses darurat baru: darurat / ' + p);
}

const POLA_RAHASIA = /(token|password|passwd|sandi|secret|rahasia|credential|kredensial|api[_-]?key|apikey|hash|salt|authorization|otp|pin)/i;
function redaksi_(o, depth) {
  depth = depth || 0;
  if (o === null || typeof o !== 'object' || depth > 4) return o;
  if (Array.isArray(o)) return o.map(function (x) { return redaksi_(x, depth + 1); });
  const out = {};
  Object.keys(o).forEach(function (k) { out[k] = POLA_RAHASIA.test(k) ? '[DISAMARKAN]' : redaksi_(o[k], depth + 1); });
  return out;
}

// ============================================================
// 3. CACHE BERVERSI & CACHEX (scale-turbo)
// ============================================================
const CacheX = {
  SZ: 50000,
  c: function () { return CacheService.getScriptCache(); },
  get: function (key) {
    try {
      const c = this.c(), head = c.get(key);
      if (head == null) return null;
      if (head.indexOf('__chunks:') !== 0) return JSON.parse(head);
      const n = +head.slice(9), keys = [];
      for (let i = 0; i < n; i++) keys.push(key + '#' + i);
      const parts = c.getAll(keys);
      let s = '';
      for (let i = 0; i < n; i++) { if (parts[keys[i]] == null) return null; s += parts[keys[i]]; }
      return JSON.parse(s);
    } catch (e) { return null; }
  },
  put: function (key, val, ttl) {
    try {
      const s = JSON.stringify(val), c = this.c();
      if (s.length <= this.SZ) { c.put(key, s, ttl); return true; }
      const n = Math.ceil(s.length / this.SZ);
      if (n > 20) return false;
      const m = {};
      for (let i = 0; i < n; i++) m[key + '#' + i] = s.substr(i * this.SZ, this.SZ);
      c.putAll(m, ttl);
      c.put(key, '__chunks:' + n, ttl);
      return true;
    } catch (e) { return false; }
  }
};
function bump(scope) { CacheService.getScriptCache().put('ver_' + scope, String(Date.now()), 21600); }
function ver_(scope) { return CacheService.getScriptCache().get('ver_' + scope) || '0'; }
function bootKey_(email) { return 'boot_' + ver_('global') + '_' + ver_('t_Pengguna') + '_' + ver_('t_Template') + '_' + email; }

// ============================================================
// 4. AKSES SHEET (header-based, teks polos)
// ============================================================
function ss_() {
  const id = prop_('SPREADSHEET_ID');
  if (!id) throw new Error('BELUM_SETUP');
  return SpreadsheetApp.openById(id);
}
function sheet_(n) {
  const s = ss_().getSheetByName(n);
  if (!s) throw new Error('SHEET_TIDAK_ADA:' + n);
  return s;
}
function tabel_(n) {
  const sh = sheet_(n), v = sh.getDataRange().getValues(), h = v[0], out = [];
  for (let i = 1; i < v.length; i++) {
    if (String(v[i][0]) === '') continue;
    const o = { _r: i + 1 };
    for (let c = 0; c < h.length; c++) o[h[c]] = v[i][c] === null || v[i][c] === undefined ? '' : String(v[i][c]);
    out.push(o);
  }
  return out;
}
// Tabel kecil dengan cache berversi (Pengguna, Template, Pejabat, Instansi)
function tabelC_(n) {
  const key = 'tb_' + n + '_' + ver_('t_' + n);
  const hit = CacheX.get(key);
  if (hit) return hit;
  const d = tabel_(n);
  CacheX.put(key, d, 600);
  return d;
}
function tambahBaris_(n, obj) {
  const h = KOLOM[n];
  sheet_(n).appendRow(h.map(function (k) { return obj[k] === undefined || obj[k] === null ? '' : String(obj[k]); }));
  bump('t_' + n);
}
function ubahBaris_(n, r, patch) {
  const h = KOLOM[n], sh = sheet_(n), rng = sh.getRange(r, 1, 1, h.length), row = rng.getValues()[0];
  Object.keys(patch).forEach(function (k) { const c = h.indexOf(k); if (c > -1) row[c] = patch[k] === null || patch[k] === undefined ? '' : String(patch[k]); });
  rng.setValues([row]);
  bump('t_' + n);
}
function denganLock_(fn) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try { return fn(); } finally { lock.releaseLock(); }
}
function catat_(email, aksi, idPengajuan, detail) {
  try {
    sheet_('Log').appendRow([new Date().toISOString(), email || '', aksi, idPengajuan || '', typeof detail === 'object' ? JSON.stringify(redaksi_(detail)) : String(detail || '')]);
  } catch (e) { queueLog(email, 'LOG', aksi, 'gagal tulis log', idPengajuan); }
}
function sekarang_() { return new Date().toISOString(); }
function normEmail_(s) { return String(s || '').trim().toLowerCase(); }
function bersih_(s, maks) {
  return String(s === undefined || s === null ? '' : s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/\{\{/g, '{ {').replace(/\}\}/g, '} }').trim().slice(0, maks || 500);
}
function bool_(v) { return v === true || String(v).toUpperCase() === 'TRUE' || v === '1'; }
function pad_(n, w) { let s = String(n); while (s.length < w) s = '0' + s; return s; }
function tglId_(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso || ''));
  return m ? (parseInt(m[3], 10) + ' ' + BULAN_ID[parseInt(m[2], 10) - 1] + ' ' + m[1]) : String(iso || '');
}
function daftarProp_(key) { return prop_(key, '').split(',').map(normEmail_).filter(Boolean); }
function jakartaSekarang_() { return Utilities.formatDate(new Date(), 'Asia/Jakarta', "yyyy-MM-dd'T'HH:mm:ss"); }
function hariIni_() { return Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyy-MM-dd'); }

// ============================================================
// 5. LOGIN GOOGLE (ID token), MODE AKSES, SESI
// ============================================================
function getAuthConfig_() {
  return ok_({ clientId: prop_('GOOGLE_CLIENT_ID'), daftarMandiri: prop_('DAFTAR_MANDIRI', 'true') === 'true', namaOrg: prop_('NAMA_ORG', 'Organisasi') });
}
function verifikasiIdToken_(idToken) {
  if (!idToken) throw new Error('UNAUTHENTICATED');
  const res = UrlFetchApp.fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(idToken), { muteHttpExceptions: true });
  if (res.getResponseCode() !== 200) throw new Error('UNAUTHENTICATED');
  const info = JSON.parse(res.getContentText());
  if (!prop_('GOOGLE_CLIENT_ID') || info.aud !== prop_('GOOGLE_CLIENT_ID')) throw new Error('UNAUTHENTICATED');
  if (String(info.email_verified) !== 'true') throw new Error('UNAUTHENTICATED');
  return { email: normEmail_(info.email), nama: bersih_(info.name || '', 120) };
}
function isDomainInstitusi_(email) { return daftarProp_('DOMAIN_IZIN').indexOf(email.split('@')[1] || '') !== -1; }
function isGmailUmum_(email) { const d = email.split('@')[1] || ''; return d === 'gmail.com' || d === 'googlemail.com'; }

function ambilPengguna_(email) {
  const r = tabel_('Pengguna').filter(function (p) { return normEmail_(p.email) === email; })[0];
  return r ? { email: email, role: String(r.role || 'USER').toUpperCase(), status: String(r.status || '').toUpperCase(), nama: r.nama, nip: r.nip } : null;
}
function daftarPenggunaBaru_(email, nama, role, status) {
  return denganLock_(function () {
    const ada = ambilPengguna_(email);
    if (ada) return ada;
    tambahBaris_('Pengguna', { email: email, role: role, status: status, tanggal: hariIni_(), nama: nama, unit: '', nip: '', jabatan: '', diubah: sekarang_() });
    catat_(email, 'ubah_pengguna', '', 'akun dibuat otomatis: ' + status);
    return { email: email, role: role, status: status, nama: nama };
  });
}
// Sheet Pengguna DIDAHULUKAN agar admin bisa menetapkan Pimpinan untuk akun domain (PRD risiko #3)
function cekAksesEmail_(email, nama) {
  const mode = prop_('MODE_AKSES', 'GMAIL');
  if (daftarProp_('ADMIN_EMAILS').indexOf(email) !== -1) {
    const a = ambilPengguna_(email) || daftarPenggunaBaru_(email, nama, 'ADMIN', 'AKTIF');
    return { email: email, role: 'ADMIN', status: 'AKTIF', nama: a.nama || nama };
  }
  const p = ambilPengguna_(email);
  if (p) return p;
  if (mode === 'WHITELIST') throw new Error('FORBIDDEN');
  if (isDomainInstitusi_(email)) return daftarPenggunaBaru_(email, nama, 'USER', 'AKTIF');
  if (mode === 'INSTITUSI') throw new Error('FORBIDDEN');
  if (mode === 'CAMPURAN' && !isGmailUmum_(email)) throw new Error('FORBIDDEN');
  if (prop_('DAFTAR_MANDIRI', 'true') !== 'true') throw new Error('FORBIDDEN');
  return daftarPenggunaBaru_(email, nama, 'USER', 'MENUNGGU');
}

function loginDenganGoogle(idToken) {
  const g = verifikasiIdToken_(idToken);
  const sesi = cekAksesEmail_(g.email, g.nama);
  if (sesi.status === 'MENUNGGU') throw new Error('PENDING_APPROVAL');
  if (sesi.status !== 'AKTIF') throw new Error('FORBIDDEN');
  catat_(sesi.email, 'login', '', 'google');
  return ok_({ token: buatSesi_(sesi.email, sesi.role, sesi.nama || g.nama, false, false), role: sesi.role, nama: sesi.nama || g.nama, email: sesi.email });
}

// ---------- Login NIP / sandi (jalur kedua) ----------
function kunciCred_(nip) { return 'CRED_' + String(nip).toLowerCase().replace(/[^a-z0-9]/g, ''); }
function loginNip_(nipIn, sandiIn) {
  const nip = String(nipIn || '').trim().toLowerCase(), sandi = String(sandiIn || '');
  if (!nip || !sandi || nip.length > 80 || sandi.length > 200) throw new Error('KREDENSIAL_KOSONG');
  const kk = 'KUNCI_' + nip.replace(/[^a-z0-9]/g, '');
  if (Number(prop_(kk) || 0) > Date.now()) throw new Error('AKUN_TERKUNCI');
  const cache = CacheService.getScriptCache(), kg = 'gagal_' + kk;
  const gagal = function () {
    const n = Number(cache.get(kg) || 0) + 1;
    if (n >= 5) { setProp_(kk, Date.now() + 15 * 60 * 1000); cache.remove(kg); catat_(nip, 'login_gagal', '', 'akun terkunci 15 menit'); }
    else cache.put(kg, String(n), 900);
    throw new Error('NIP_ATAU_SANDI_SALAH');
  };
  // Akun darurat sistem
  if (nip === String(prop_('EMERGENCY_USER', 'darurat')).toLowerCase()) {
    if (!samaAman_(hashPass_(sandi, prop_('EMERGENCY_SALT')), prop_('EMERGENCY_PASS_HASH'))) gagal();
    cache.remove(kg);
    catat_('darurat', 'login', '', 'akses darurat');
    return ok_({ token: buatSesi_('darurat', 'ADMIN', 'Akun Darurat', true, false), role: 'ADMIN', nama: 'Akun Darurat', email: 'darurat', darurat: true });
  }
  const p = tabel_('Pengguna').filter(function (x) { return String(x.nip).trim().toLowerCase() === nip || normEmail_(x.email) === nip; })[0];
  let cred = null;
  try { cred = p && p.nip ? JSON.parse(prop_(kunciCred_(p.nip)) || 'null') : null; } catch (e) { cred = null; }
  const salt = cred ? cred.s : 'dummy-salt', h = hashPass_(sandi, salt); // selalu hitung hash (cegah beda waktu)
  if (!p || !cred || !samaAman_(h, cred.h)) gagal();
  cache.remove(kg);
  const status = String(p.status).toUpperCase();
  if (status === 'MENUNGGU') throw new Error('PENDING_APPROVAL');
  if (status !== 'AKTIF') throw new Error('FORBIDDEN');
  const email = normEmail_(p.email);
  const role = daftarProp_('ADMIN_EMAILS').indexOf(email) !== -1 ? 'ADMIN' : String(p.role).toUpperCase();
  catat_(email, 'login', '', 'nip');
  return ok_({ token: buatSesi_(email, role, p.nama, false, !!cred.w), role: role, nama: p.nama, email: email, wajibGanti: !!cred.w });
}

function aturSandi_(b) {
  const s = requireSesi_(b.token, ['ADMIN']);
  const email = normEmail_(b.email);
  const p = tabel_('Pengguna').filter(function (x) { return normEmail_(x.email) === email; })[0];
  if (!p) throw new Error('TIDAK_DITEMUKAN');
  if (!String(p.nip).trim()) throw new Error('NIP_BELUM_DIISI');
  const sementara = sandiAcak_(10), salt = Utilities.getUuid();
  setProp_(kunciCred_(p.nip), JSON.stringify({ h: hashPass_(sementara, salt), s: salt, w: 1 }));
  delProp_('KUNCI_' + String(p.nip).toLowerCase().replace(/[^a-z0-9]/g, ''));
  revokeAll_(email);
  catat_(s.email, 'ubah_pengguna', '', 'atur sandi sementara untuk ' + email);
  return ok_({ sandiSementara: sementara, nip: p.nip, catatan: 'Sandi hanya tampil sekali. Pengguna wajib menggantinya saat login pertama.' });
}
function ubahSandi_(b) {
  const s = requireSesi_(b.token, null, { bolehWajibGanti: true });
  if (s.darurat) throw new Error('GUNAKAN_RESET_DARURAT');
  const baru = String(b.baru || '');
  if (baru.length < 8 || baru.length > 100 || !/\d/.test(baru) || !/[A-Za-z]/.test(baru)) throw new Error('SANDI_LEMAH');
  const p = ambilPengguna_(s.email);
  if (!p || !p.nip) throw new Error('NIP_BELUM_DIISI');
  let cred = null;
  try { cred = JSON.parse(prop_(kunciCred_(p.nip)) || 'null'); } catch (e) { cred = null; }
  if (cred && !samaAman_(hashPass_(String(b.lama || ''), cred.s), cred.h)) throw new Error('SANDI_LAMA_SALAH');
  if (!cred && !s.wajibGanti) {
    // pengguna Google yang baru membuat sandi NIP: tetap wajib sandi lama kosong → tolak
    throw new Error('SANDI_LAMA_SALAH');
  }
  const salt = Utilities.getUuid();
  setProp_(kunciCred_(p.nip), JSON.stringify({ h: hashPass_(baru, salt), s: salt, w: 0 }));
  revokeAll_(s.email);
  catat_(s.email, 'ubah_pengguna', '', 'ubah sandi sendiri');
  return ok_({ token: buatSesi_(s.email, s.role, s.nama, false, false) });
}

// ---------- Pemeriksa sesi & peran (wajib di tiap fungsi sensitif) ----------
function requireSesiToken_(token) {
  const s = verifyToken_(token);
  if (!s) throw new Error('UNAUTHENTICATED');
  return s;
}
function requireSesi_(token, roles, opsi) {
  const s = requireSesiToken_(token);
  if (s.darurat) {
    if (roles && roles.indexOf('ADMIN') === -1) throw new Error('FORBIDDEN');
    return { email: 'darurat', role: 'ADMIN', nama: 'Akun Darurat', darurat: true, unit: '' };
  }
  if (s.wajibGanti && !(opsi && opsi.bolehWajibGanti)) throw new Error('WAJIB_GANTI_SANDI');
  const email = normEmail_(s.email);
  const admin = daftarProp_('ADMIN_EMAILS').indexOf(email) !== -1;
  const u = tabelC_('Pengguna').filter(function (x) { return normEmail_(x.email) === email; })[0];
  if (!u && !admin) throw new Error('FORBIDDEN');
  const status = admin ? 'AKTIF' : String(u.status).toUpperCase();
  if (status === 'MENUNGGU') throw new Error('PENDING_APPROVAL');
  if (status !== 'AKTIF') throw new Error('FORBIDDEN');
  const role = admin ? 'ADMIN' : String(u.role).toUpperCase();
  if (roles && roles.indexOf(role) === -1) throw new Error('FORBIDDEN');
  return { email: email, role: role, nama: (u && u.nama) || s.nama, unit: (u && u.unit) || '', nip: (u && u.nip) || '', jabatan: (u && u.jabatan) || '' };
}

// ============================================================
// 6. KELOLA PENGGUNA, INSTANSI, PERSONEL
// ============================================================
function penggunaOut_(p) {
  return { email: p.email, role: String(p.role).toUpperCase(), status: String(p.status).toUpperCase(), tanggal: p.tanggal, nama: p.nama, unit: p.unit, nip: p.nip, jabatan: p.jabatan, diubah: p.diubah, adaSandi: !!(p.nip && prop_(kunciCred_(p.nip))) };
}
function listPengguna_(b) {
  requireSesi_(b.token, ['ADMIN']);
  const q = String(b.q || '').toLowerCase(), role = b.role || '', status = b.status || '', unit = String(b.unit || '').toLowerCase();
  let rows = tabel_('Pengguna');
  const ringkas = { total: rows.length, aktif: 0, menunggu: 0, blokir: 0, pimpinan: 0, admin: 0, user: 0 };
  rows.forEach(function (p) {
    const st = String(p.status).toUpperCase(), r = String(p.role).toUpperCase();
    if (st === 'AKTIF') ringkas.aktif++; else if (st === 'MENUNGGU') ringkas.menunggu++; else if (st === 'BLOKIR') ringkas.blokir++;
    if (r === 'PIMPINAN') ringkas.pimpinan++; else if (r === 'ADMIN') ringkas.admin++; else ringkas.user++;
  });
  rows = rows.filter(function (p) {
    if (role && String(p.role).toUpperCase() !== role) return false;
    if (status && String(p.status).toUpperCase() !== status) return false;
    if (unit && String(p.unit).toLowerCase().indexOf(unit) === -1) return false;
    if (q && (p.nama + ' ' + p.email + ' ' + p.nip + ' ' + p.unit).toLowerCase().indexOf(q) === -1) return false;
    return true;
  });
  return ok_(Object.assign({ ringkas: ringkas }, halaman_(rows.map(penggunaOut_), b)));
}
function halaman_(arr, b) {
  const per = Math.min(Math.max(parseInt(b.perPage, 10) || 10, 1), 100), total = arr.length;
  const pages = Math.max(1, Math.ceil(total / per)), page = Math.min(Math.max(parseInt(b.page, 10) || 1, 1), pages);
  return { rows: arr.slice((page - 1) * per, page * per), total: total, page: page, pages: pages, perPage: per };
}
function tambahPengguna_(b) {
  const s = requireSesi_(b.token, ['ADMIN']);
  const email = normEmail_(b.email);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('EMAIL_TIDAK_VALID');
  const role = String(b.role || 'USER').toUpperCase();
  if (ROLES.indexOf(role) === -1) throw new Error('ROLE_TIDAK_VALID');
  if (email === s.email) throw new Error('TIDAK_BOLEH_UBAH_DIRI_SENDIRI');
  denganLock_(function () {
    if (ambilPengguna_(email)) throw new Error('SUDAH_ADA');
    tambahBaris_('Pengguna', { email: email, role: role, status: 'AKTIF', tanggal: hariIni_(), nama: bersih_(b.nama, 120), unit: bersih_(b.unit, 150), nip: bersih_(b.nip, 40), jabatan: bersih_(b.jabatan, 120), diubah: sekarang_() });
  });
  catat_(s.email, 'ubah_pengguna', '', 'tambah ' + email + ' (' + role + ')');
  bump('global');
  return ok_({ pesan: 'Pengguna ditambahkan' });
}
function ubahPengguna_(b) {
  const s = requireSesi_(b.token, ['ADMIN']);
  const email = normEmail_(b.email);
  const adminProp = daftarProp_('ADMIN_EMAILS').indexOf(email) !== -1;
  return denganLock_(function () {
    const p = tabel_('Pengguna').filter(function (x) { return normEmail_(x.email) === email; })[0];
    if (!p) throw new Error('TIDAK_DITEMUKAN');
    const patch = { diubah: sekarang_() };
    const ubahPeran = b.role !== undefined && String(b.role).toUpperCase() !== String(p.role).toUpperCase();
    const ubahStatus = b.status !== undefined && String(b.status).toUpperCase() !== String(p.status).toUpperCase();
    if ((ubahPeran || ubahStatus) && (email === s.email || adminProp)) throw new Error('TIDAK_BOLEH_UBAH_DIRI_SENDIRI');
    if (b.role !== undefined) { const r = String(b.role).toUpperCase(); if (ROLES.indexOf(r) === -1) throw new Error('ROLE_TIDAK_VALID'); patch.role = r; }
    if (b.status !== undefined) { const st = String(b.status).toUpperCase(); if (['AKTIF', 'MENUNGGU', 'BLOKIR'].indexOf(st) === -1) throw new Error('STATUS_TIDAK_VALID'); patch.status = st; }
    ['nama', 'unit', 'nip', 'jabatan'].forEach(function (k) { if (b[k] !== undefined) patch[k] = bersih_(b[k], k === 'unit' ? 150 : 120); });
    ubahBaris_('Pengguna', p._r, patch);
    if (patch.status === 'BLOKIR' || patch.role) revokeAll_(email);
    catat_(s.email, 'ubah_pengguna', '', email + ' → ' + JSON.stringify(redaksi_({ role: patch.role, status: patch.status })));
    bump('global');
    return ok_({ pesan: 'Pengguna diperbarui' });
  });
}
function listPersonel_(b) {
  requireSesi_(b.token, null);
  return ok_({ rows: tabelC_('Pengguna').filter(function (p) { return String(p.status).toUpperCase() === 'AKTIF'; }).map(function (p) { return { email: p.email, nama: p.nama || p.email, nip: p.nip, jabatan: p.jabatan, unit: p.unit }; }) });
}
function listInstansi_(b) {
  const s = requireSesi_(b.token, null);
  let rows = tabelC_('Instansi');
  if (s.role !== 'ADMIN' || !b.semua) rows = rows.filter(function (r) { return bool_(r.aktif); });
  return ok_({ rows: rows.map(function (r) { return { id: r.id, nama: r.nama, jenis: r.jenis, alamat: r.alamat, kontak: r.kontak, email: r.email, aktif: bool_(r.aktif) }; }) });
}
function simpanInstansi_(b) {
  const s = requireSesi_(b.token, ['ADMIN']);
  const nama = bersih_(b.nama, 150);
  if (!nama) throw new Error('NAMA_WAJIB');
  const jenis = String(b.jenis || 'EKSTERNAL').toUpperCase() === 'INTERNAL' ? 'INTERNAL' : 'EKSTERNAL';
  return denganLock_(function () {
    const rows = tabel_('Instansi');
    const data = { nama: nama, jenis: jenis, alamat: bersih_(b.alamat, 300), kontak: bersih_(b.kontak, 60), email: bersih_(b.email, 120), aktif: b.aktif === false ? 'FALSE' : 'TRUE' };
    if (b.id) {
      const r = rows.filter(function (x) { return x.id === b.id; })[0];
      if (!r) throw new Error('TIDAK_DITEMUKAN');
      ubahBaris_('Instansi', r._r, data);
    } else {
      data.id = 'INS-' + pad_(rows.length + 1, 4) + '-' + acak_(3, 'ABCDEFGHJKLMNPQRSTUVWXYZ');
      tambahBaris_('Instansi', data);
    }
    catat_(s.email, 'instansi', '', (b.id ? 'ubah ' : 'tambah ') + nama);
    return ok_({ pesan: 'Instansi disimpan' });
  });
}

// ============================================================
// 7. TEMPLATE, PEJABAT, PENOMORAN
// ============================================================
function docIdDari_(s) {
  s = String(s || '').trim();
  const m = /\/d\/([a-zA-Z0-9_-]{20,})/.exec(s);
  if (m) return m[1];
  if (/^[a-zA-Z0-9_-]{20,}$/.test(s)) return s;
  throw new Error('ID_DOCS_TIDAK_VALID');
}
function parseIsian_(s) { try { const a = JSON.parse(s || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
function templateOut_(t, penuh) {
  const o = { kode: t.kode, nama: t.nama, deskripsi: t.deskripsi, isian: parseIsian_(t.isian), bolehPemohon: bool_(t.boleh_pemohon), aktif: bool_(t.aktif) };
  if (penuh) { o.idDocs = t.id_docs; o.formatNomor = t.format_nomor; o.resetNomor = t.reset_nomor; o.pejabatEmail = t.pejabat_email; o.mulaiNomor = Number(t.mulai_nomor || 1); }
  return o;
}
function templateByKode_(kode) {
  const t = tabelC_('Template').filter(function (x) { return x.kode === kode; })[0];
  if (!t) throw new Error('JENIS_TIDAK_DITEMUKAN');
  return t;
}
function listTemplate_(b) {
  const s = requireSesi_(b.token, null);
  if (s.role === 'ADMIN') return ok_({ rows: tabelC_('Template').map(function (t) { return templateOut_(t, true); }), pola: previewNomorSemua_() });
  const rows = tabelC_('Template').filter(function (t) { return bool_(t.aktif) && (bool_(t.boleh_pemohon) || s.role === 'PIMPINAN'); });
  return ok_({ rows: rows.map(function (t) { return templateOut_(t, false); }) });
}
function previewNomorSemua_() {
  const out = {}, now = new Date();
  tabel_('Nomor');
  tabelC_('Template').forEach(function (t) {
    try { out[t.kode] = formatNomor_(t.format_nomor, ambilTerakhir_(t, now) + 1, t.kode, now); } catch (e) { out[t.kode] = ''; }
  });
  return out;
}
function getPenandaDocs_(b) {
  requireSesi_(b.token, ['ADMIN']);
  const id = docIdDari_(b.idDocs);
  let doc;
  try { doc = DocumentApp.openById(id); } catch (e) { throw new Error('DOCS_TIDAK_BISA_DIBUKA'); }
  const teks = doc.getBody().getText() + ' ' + (doc.getHeader() ? doc.getHeader().getText() : '') + ' ' + (doc.getFooter() ? doc.getFooter().getText() : '');
  const set = {}, re = /\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g;
  let m;
  while ((m = re.exec(teks))) set[m[1]] = true;
  const tags = Object.keys(set);
  return ok_({ judul: doc.getName(), id: id, tagSistem: tags.filter(function (t) { return TAG_SISTEM.indexOf(t) !== -1; }), tagIsian: tags.filter(function (t) { return TAG_SISTEM.indexOf(t) === -1; }) });
}
function simpanTemplate_(b) {
  const s = requireSesi_(b.token, ['ADMIN']);
  const kode = bersih_(b.kode, 5).toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!kode) throw new Error('KODE_WAJIB');
  const nama = bersih_(b.nama, 100);
  if (!nama) throw new Error('NAMA_WAJIB');
  const idDocs = docIdDari_(b.idDocs);
  const pola = String(b.formatNomor || '').trim();
  if (!/\{no(:0+)?\}/.test(pola)) throw new Error('POLA_NOMOR_HARUS_MEMUAT_{no}');
  if (!/^[A-Za-z0-9{}_:\/\-\. ]+$/.test(pola) || pola.length > 80) throw new Error('POLA_NOMOR_TIDAK_VALID');
  const reset = ['TAHUNAN', 'BULANAN', 'TIDAK'].indexOf(String(b.resetNomor)) > -1 ? b.resetNomor : 'TAHUNAN';
  const isian = (Array.isArray(b.isian) ? b.isian : []).slice(0, 40).map(function (f) {
    const tipe = ['text', 'textarea', 'date', 'number', 'select', 'personel', 'instansi'].indexOf(f.tipe) > -1 ? f.tipe : 'text';
    const tag = String(f.tag || '').replace(/[^a-zA-Z0-9_]/g, '');
    if (!tag || TAG_SISTEM.indexOf(tag) !== -1) throw new Error('TAG_TIDAK_VALID:' + tag);
    return { tag: tag, label: bersih_(f.label || tag, 80), tipe: tipe, wajib: f.wajib !== false, opsi: bersih_(f.opsi, 300), bantuan: bersih_(f.bantuan, 120) };
  });
  if (b.pejabatEmail && !tabelC_('Pejabat').some(function (p) { return normEmail_(p.email) === normEmail_(b.pejabatEmail); })) throw new Error('PEJABAT_TIDAK_ADA');
  return denganLock_(function () {
    const rows = tabel_('Template'), ada = rows.filter(function (x) { return x.kode === kode; })[0];
    const data = { kode: kode, nama: nama, id_docs: idDocs, isian: JSON.stringify(isian), format_nomor: pola, reset_nomor: reset, pejabat_email: normEmail_(b.pejabatEmail), boleh_pemohon: b.bolehPemohon === false ? 'FALSE' : 'TRUE', aktif: b.aktif === false ? 'FALSE' : 'TRUE', mulai_nomor: String(Math.max(1, parseInt(b.mulaiNomor, 10) || 1)), deskripsi: bersih_(b.deskripsi, 250) };
    if (ada) ubahBaris_('Template', ada._r, data); else tambahBaris_('Template', data);
    catat_(s.email, 'template', '', (ada ? 'ubah ' : 'tambah ') + kode);
    bump('global');
    return ok_({ pesan: 'Template disimpan', kode: kode });
  });
}
function listPejabat_(b) {
  requireSesi_(b.token, ['ADMIN']);
  return ok_({ rows: tabelC_('Pejabat').map(function (p) { return { email: p.email, nama: p.nama, jabatan: p.jabatan, nip: p.nip, adaTtd: !!p.id_ttd, adaCap: !!p.id_cap, jenis: p.jenis_diizinkan }; }) });
}
function simpanGambarPrivat_(base64, nama) {
  if (!base64) return '';
  const bytes = Utilities.base64Decode(String(base64).split(',').pop());
  if (bytes.length > 1024 * 1024) throw new Error('GAMBAR_TERLALU_BESAR');
  const blob = Utilities.newBlob(bytes, 'image/png', nama + '.png');
  const f = DriveApp.getFolderById(prop_('FOLDER_TTD')).createFile(blob);
  f.setSharing(DriveApp.Access.PRIVATE, DriveApp.Permission.NONE);
  return f.getId();
}
function simpanPejabat_(b) {
  const s = requireSesi_(b.token, ['ADMIN']);
  const email = normEmail_(b.email);
  const u = ambilPengguna_(email);
  if (!u) throw new Error('PENGGUNA_TIDAK_ADA');
  const jenis = Array.isArray(b.jenis) ? b.jenis.map(function (x) { return String(x).replace(/[^A-Za-z0-9*]/g, ''); }).join(',') : String(b.jenis || '').replace(/[^A-Za-z0-9,*]/g, '');
  const idTtd = simpanGambarPrivat_(b.ttdBase64, 'ttd_' + email), idCap = simpanGambarPrivat_(b.capBase64, 'cap_' + email);
  return denganLock_(function () {
    const ada = tabel_('Pejabat').filter(function (x) { return normEmail_(x.email) === email; })[0];
    const data = { email: email, nama: bersih_(b.nama || u.nama, 120), jabatan: bersih_(b.jabatan, 150), nip: bersih_(b.nip || u.nip, 40), jenis_diizinkan: jenis };
    if (idTtd) data.id_ttd = idTtd;
    if (idCap) data.id_cap = idCap;
    if (ada) ubahBaris_('Pejabat', ada._r, data); else tambahBaris_('Pejabat', data);
    catat_(s.email, 'pejabat', '', 'simpan ' + email);
    return ok_({ pesan: 'Pejabat disimpan' });
  });
}
function pejabatByEmail_(email) {
  return tabelC_('Pejabat').filter(function (p) { return normEmail_(p.email) === normEmail_(email); })[0] || null;
}
function pimpinanBolehJenis_(email, jenis) {
  const p = pejabatByEmail_(email);
  if (!p) return false;
  const j = String(p.jenis_diizinkan || '').split(',').map(function (x) { return x.trim(); });
  return j.indexOf('*') > -1 || j.indexOf(jenis) > -1;
}

// ---------- Penomoran (dijaga LockService oleh pemanggil) ----------
function periode_(reset, d) {
  const y = Utilities.formatDate(d, 'Asia/Jakarta', 'yyyy'), m = Utilities.formatDate(d, 'Asia/Jakarta', 'MM');
  return reset === 'TAHUNAN' ? y : reset === 'BULANAN' ? y + '-' + m : 'SEMUA';
}
function formatNomor_(pola, no, kode, d) {
  const y = Utilities.formatDate(d, 'Asia/Jakarta', 'yyyy'), m = parseInt(Utilities.formatDate(d, 'Asia/Jakarta', 'MM'), 10);
  return String(pola)
    .replace(/\{no(?::(0+))?\}/g, function (x, z) { return z ? pad_(no, z.length) : String(no); })
    .replace(/\{kode\}/g, kode)
    .replace(/\{bulan_romawi\}/g, ROMAWI[m])
    .replace(/\{bulan\}/g, pad_(m, 2))
    .replace(/\{tahun\}/g, y);
}
function ambilTerakhir_(tpl, d) {
  const per = periode_(tpl.reset_nomor, d);
  const r = tabel_('Nomor').filter(function (x) { return x.jenis === tpl.kode && x.periode === per; })[0];
  return r ? Number(r.terakhir) : Math.max(0, Number(tpl.mulai_nomor || 1) - 1);
}
function naikkanNomor_(jenis, resetNomor, mulai, d) {
  const per = periode_(resetNomor, d);
  const r = tabel_('Nomor').filter(function (x) { return x.jenis === jenis && x.periode === per; })[0];
  const no = (r ? Number(r.terakhir) : Math.max(0, Number(mulai || 1) - 1)) + 1;
  if (r) ubahBaris_('Nomor', r._r, { terakhir: no }); else tambahBaris_('Nomor', { jenis: jenis, periode: per, terakhir: no });
  return no;
}

// ============================================================
// 8. VALIDASI ISIAN & PEMBUATAN PDF
// ============================================================
function validasiIsian_(isian, data) {
  const out = {};
  data = data || {};
  isian.forEach(function (f) {
    let v = data[f.tag];
    v = v === undefined || v === null ? '' : v;
    const kosong = String(v).trim() === '';
    if (kosong) { if (f.wajib) throw new Error('ISIAN_WAJIB:' + f.label); out[f.tag] = f.tipe === 'personel' || f.tipe === 'instansi' ? null : ''; return; }
    if (f.tipe === 'date') {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(String(v))) throw new Error('TANGGAL_TIDAK_VALID:' + f.label);
      out[f.tag] = String(v);
    } else if (f.tipe === 'number') {
      if (isNaN(Number(v))) throw new Error('ANGKA_TIDAK_VALID:' + f.label);
      out[f.tag] = String(Number(v));
    } else if (f.tipe === 'select') {
      const opsi = String(f.opsi || '').split('|').map(function (x) { return x.trim(); });
      if (opsi.indexOf(String(v)) === -1) throw new Error('PILIHAN_TIDAK_VALID:' + f.label);
      out[f.tag] = String(v);
    } else if (f.tipe === 'personel') {
      const p = ambilPengguna_(normEmail_(v));
      if (!p) throw new Error('PERSONEL_TIDAK_DITEMUKAN:' + f.label);
      const row = tabelC_('Pengguna').filter(function (x) { return normEmail_(x.email) === p.email; })[0] || {};
      out[f.tag] = { email: p.email, nama: row.nama || p.email, nip: row.nip || '', jabatan: row.jabatan || '', unit: row.unit || '' };
    } else if (f.tipe === 'instansi') {
      const i = tabelC_('Instansi').filter(function (x) { return x.id === String(v) && bool_(x.aktif); })[0];
      if (!i) throw new Error('INSTANSI_TIDAK_DITEMUKAN:' + f.label);
      out[f.tag] = { id: i.id, nama: i.nama, alamat: i.alamat };
    } else {
      out[f.tag] = bersih_(v, f.tipe === 'textarea' ? 5000 : 300);
    }
  });
  return out;
}
function petaPengganti_(p, tpl, data, extra) {
  const map = {};
  parseIsian_(tpl.isian).forEach(function (f) {
    const v = data[f.tag];
    if (f.tipe === 'personel') {
      map[f.tag] = v ? v.nama : ''; map[f.tag + '_nip'] = v ? v.nip : ''; map[f.tag + '_jabatan'] = v ? v.jabatan : ''; map[f.tag + '_unit'] = v ? v.unit : '';
    } else if (f.tipe === 'instansi') {
      map[f.tag] = v ? v.nama : ''; map[f.tag + '_alamat'] = v ? v.alamat : '';
    } else if (f.tipe === 'date') {
      map[f.tag] = v ? tglId_(v) : '';
    } else map[f.tag] = v === undefined || v === null ? '' : String(v);
  });
  const pem = ambilPengguna_(normEmail_(p.email_pemohon)) || {};
  const pemRow = tabelC_('Pengguna').filter(function (x) { return normEmail_(x.email) === normEmail_(p.email_pemohon); })[0] || {};
  map.nomor_surat = p.nomor_surat || '(nomor diberikan saat diproses)';
  map.tanggal_terbit = tglId_((extra && extra.tanggalTerbit) || p.tgl_surat || hariIni_());
  map.nama_pejabat = (extra && extra.pejabat && extra.pejabat.nama) || '';
  map.jabatan_pejabat = (extra && extra.pejabat && extra.pejabat.jabatan) || '';
  map.nip_pejabat = (extra && extra.pejabat && extra.pejabat.nip) || '';
  map.kode_verifikasi = (extra && extra.kode) || '';
  map.nama_pemohon = pemRow.nama || pem.nama || p.email_pemohon;
  map.unit_pemohon = pemRow.unit || '';
  return map;
}
function gantiTeks_(wadah, tag, nilai) {
  const pola = '\\{\\{\\s*' + tag + '\\s*\\}\\}';
  let r = wadah.findText(pola), n = 0;
  while (r && n++ < 200) {
    const el = r.getElement().asText(), s = r.getStartOffset(), e = r.getEndOffsetInclusive();
    el.deleteText(s, e);
    if (nilai) el.insertText(s, String(nilai));
    r = wadah.findText(pola);
  }
}
function sisipGambar_(wadah, tag, blob, lebar) {
  const pola = '\\{\\{\\s*' + tag + '\\s*\\}\\}';
  let r = wadah.findText(pola), n = 0;
  while (r && n++ < 10) {
    const t = r.getElement().asText();
    t.deleteText(r.getStartOffset(), r.getEndOffsetInclusive());
    if (blob) {
      const par = t.getParent();
      let img;
      try { img = par.insertInlineImage(par.getChildIndex(t), blob); } catch (e) { img = par.appendInlineImage(blob); }
      const w = img.getWidth(), h = img.getHeight();
      if (w > 0) { img.setWidth(lebar); img.setHeight(Math.round(lebar * h / w)); }
    }
    r = wadah.findText(pola);
  }
}
function qrBlob_(url) {
  const res = UrlFetchApp.fetch('https://api.qrserver.com/v1/create-qr-code/?size=300x300&margin=4&data=' + encodeURIComponent(url), { muteHttpExceptions: true });
  if (res.getResponseCode() !== 200) throw new Error('QR_GAGAL_DIBUAT');
  return res.getBlob().setName('qr.png');
}
function namaFile_(s) { return String(s || 'surat').replace(/[\\\/:*?"<>|]+/g, '-').replace(/\s+/g, '_').slice(0, 80); }
function hmacKode_(id, nomor, jenis, tglTerbit) {
  const sig = Utilities.computeHmacSha256Signature([id, nomor, jenis, tglTerbit].join('|'), prop_('HMAC_KEY'));
  return Utilities.base64EncodeWebSafe(sig).replace(/=+$/, '').slice(0, 20);
}
/** Membuat PDF dari salinan template. final=true: sisipkan TTD, cap, QR. Salinan sementara selalu dihapus. */
function buatPdf_(p, tpl, data, opsi) {
  const final = !!(opsi && opsi.final);
  const arsip = DriveApp.getFolderById(prop_('FOLDER_ARSIP'));
  const salinan = DriveApp.getFileById(tpl.id_docs).makeCopy('tmp_' + p.id, arsip);
  try {
    const doc = DocumentApp.openById(salinan.getId());
    const wadah = [doc.getBody()];
    if (doc.getHeader()) wadah.push(doc.getHeader());
    if (doc.getFooter()) wadah.push(doc.getFooter());
    const peta = petaPengganti_(p, tpl, data, opsi);
    wadah.forEach(function (w) {
      Object.keys(peta).forEach(function (k) { gantiTeks_(w, k, peta[k]); });
      if (final) {
        const pj = opsi.pejabat;
        sisipGambar_(w, 'ttd', pj.id_ttd ? DriveApp.getFileById(pj.id_ttd).getBlob() : null, 120);
        sisipGambar_(w, 'cap', pj.id_cap ? DriveApp.getFileById(pj.id_cap).getBlob() : null, 110);
        sisipGambar_(w, 'qr', opsi.qr, 90);
      } else {
        ['ttd', 'cap', 'qr'].forEach(function (t) { gantiTeks_(w, t, t === 'ttd' ? '[menunggu tanda tangan pimpinan]' : ''); });
      }
      if (final) {
        const sisa = /\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/;
        let r = w.findText('\\{\\{\\s*[a-zA-Z0-9_]+\\s*\\}\\}'), n = 0;
        while (r && n++ < 100) { const el = r.getElement().asText(); el.deleteText(r.getStartOffset(), r.getEndOffsetInclusive()); r = w.findText('\\{\\{\\s*[a-zA-Z0-9_]+\\s*\\}\\}'); }
      }
    });
    doc.saveAndClose();
    const blob = DriveApp.getFileById(salinan.getId()).getAs('application/pdf').setName(namaFile_(final ? p.nomor_surat : 'pratinjau_' + p.id) + '.pdf');
    const f = arsip.createFile(blob);
    f.setSharing(DriveApp.Access.PRIVATE, DriveApp.Permission.NONE);
    return f.getId();
  } finally {
    try { salinan.setTrashed(true); } catch (e) { /* abaikan */ }
  }
}

// ============================================================
// 9. ALUR SURAT
// ============================================================
function unggahBerkas_(lampiran, folderKey, prefix) {
  if (!lampiran || !lampiran.base64) return '';
  const mime = String(lampiran.mime || '');
  if (MIME_LAMPIRAN.indexOf(mime) === -1) throw new Error('JENIS_BERKAS_TIDAK_DIIZINKAN');
  const bytes = Utilities.base64Decode(String(lampiran.base64).split(',').pop());
  if (bytes.length > LAMPIRAN_MAKS) throw new Error('BERKAS_TERLALU_BESAR');
  const ext = mime === 'application/pdf' ? '.pdf' : mime === 'image/png' ? '.png' : '.jpg';
  const f = DriveApp.getFolderById(prop_(folderKey)).createFile(Utilities.newBlob(bytes, mime, namaFile_(prefix + '_' + (lampiran.nama || 'lampiran').replace(/\.[a-z]+$/i, '')) + ext));
  f.setSharing(DriveApp.Access.PRIVATE, DriveApp.Permission.NONE);
  return f.getId();
}
function perihalDari_(tpl, data) {
  const isian = parseIsian_(tpl.isian);
  const pref = ['perihal', 'keperluan', 'judul', 'acara'];
  for (let i = 0; i < pref.length; i++) if (data[pref[i]] && typeof data[pref[i]] === 'string') return data[pref[i]].slice(0, 140);
  for (let j = 0; j < isian.length; j++) { const v = data[isian[j].tag]; if (typeof v === 'string' && v && isian[j].tipe !== 'date') return v.slice(0, 140); }
  return tpl.nama;
}
function suratOut_(p, opsi) {
  opsi = opsi || {};
  let tpl = null;
  try { tpl = tabelC_('Template').filter(function (t) { return t.kode === p.jenis; })[0] || null; } catch (e) { tpl = null; }
  let data = {};
  try { data = JSON.parse(p.data || '{}'); } catch (e) { data = {}; }
  const pem = tabelC_('Pengguna').filter(function (x) { return normEmail_(x.email) === normEmail_(p.email_pemohon); })[0] || {};
  const o = { id: p.id, tanggal: p.tanggal, jenis: p.jenis, namaJenis: tpl ? tpl.nama : p.jenis, status: p.status, nomor: p.nomor_surat, statusNomor: p.status_nomor, perihal: tpl ? perihalDari_(tpl, data) : '', pemohon: { email: p.email_pemohon, nama: pem.nama || p.email_pemohon, unit: pem.unit || '' }, catatanPenolakan: p.catatan_penolakan, tanggalTerbit: p.tanggal_terbit, bisaUnduh: p.status === 'TERBIT' && !!p.id_pdf, adaLampiran: !!p.id_lampiran, pejabatEmail: p.pejabat_email };
  if (opsi.detail) { o.data = data; o.catatanAdmin = p.catatan_admin; o.isian = tpl ? parseIsian_(tpl.isian) : []; o.pemverifikasi = p.email_pemverifikasi; o.waktuVerifikasi = p.waktu_verifikasi; o.tglSurat = p.tgl_surat; }
  return o;
}
function pengajuanById_(id) {
  const r = tabel_('Pengajuan').filter(function (x) { return x.id === id; })[0];
  if (!r) throw new Error('SURAT_TIDAK_DITEMUKAN');
  return r;
}
function bolehLihat_(s, p) {
  if (s.role === 'ADMIN') return true;
  if (normEmail_(p.email_pemohon) === s.email) return true;
  if (s.role === 'PIMPINAN' && pimpinanBolehJenis_(s.email, p.jenis)) return true;
  return false;
}
function idBaru_() {
  const pre = 'REG-' + Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyy-MM') + '-';
  const n = tabel_('Pengajuan').filter(function (x) { return x.id.indexOf(pre) === 0; }).length + 1;
  return pre + pad_(n, 3);
}
function buatPengajuan_(s, b, langsung) {
  const tpl = templateByKode_(String(b.jenis || ''));
  if (!bool_(tpl.aktif)) throw new Error('JENIS_TIDAK_AKTIF');
  if (!langsung && s.role === 'USER' && !bool_(tpl.boleh_pemohon)) throw new Error('FORBIDDEN');
  const data = validasiIsian_(parseIsian_(tpl.isian), b.data);
  const idLamp = unggahBerkas_(b.lampiran, 'FOLDER_LAMPIRAN', 'lamp');
  let id;
  denganLock_(function () {
    id = idBaru_();
    tambahBaris_('Pengajuan', { id: id, tanggal: sekarang_(), jenis: tpl.kode, email_pemohon: s.email, data: JSON.stringify(data), status: langsung ? 'DIPROSES' : 'DIAJUKAN', id_lampiran: idLamp, pejabat_email: tpl.pejabat_email, tgl_surat: hariIni_() });
  });
  catat_(s.email, 'ajukan', id, (langsung ? 'langsung ' : '') + tpl.kode);
  bump('global');
  return { id: id, tpl: tpl };
}
function ajukan_(b) {
  const s = requireSesi_(b.token, null);
  const r = buatPengajuan_(s, b, false);
  admins_().forEach(function (e) { notif_(e, 'Pengajuan surat baru ' + r.id, 'Ada pengajuan ' + r.tpl.nama + ' dari ' + (s.nama || s.email) + ' yang perlu diproses.'); });
  return ok_({ id: r.id, pesan: 'Pengajuan terkirim' });
}
function buatLangsung_(b) {
  const s = requireSesi_(b.token, ['ADMIN']);
  const r = buatPengajuan_(s, b, true);
  const hasil = prosesDanNomori_({ token: b.token, id: r.id, pejabatEmail: b.pejabatEmail });
  return ok_({ id: r.id, nomor: hasil.nomor, pesan: 'Surat dibuat dan dikirim ke pimpinan' });
}
function listRiwayat_(b) {
  const s = requireSesi_(b.token, null);
  const q = String(b.q || '').toLowerCase();
  let rows = tabel_('Pengajuan').filter(function (p) { return normEmail_(p.email_pemohon) === s.email; });
  const ringkas = { total: rows.length, proses: 0, terbit: 0, ditolak: 0 };
  rows.forEach(function (p) {
    if (p.status === 'TERBIT') ringkas.terbit++; else if (p.status === 'DITOLAK' || p.status === 'DIBATALKAN') ringkas.ditolak++; else ringkas.proses++;
  });
  rows = rows.filter(function (p) {
    if (b.jenis && p.jenis !== b.jenis) return false;
    if (b.status === 'PROSES' ? ['DIAJUKAN', 'DIPROSES', 'MENUNGGU_VERIFIKASI'].indexOf(p.status) === -1 : (b.status && p.status !== b.status)) return false;
    if (b.tahun && String(p.tanggal).slice(0, 4) !== String(b.tahun)) return false;
    return true;
  }).sort(function (x, y) { return x.tanggal < y.tanggal ? 1 : -1; });
  let out = rows.map(function (p) { return suratOut_(p); });
  if (q) out = out.filter(function (o) { return (o.nomor + ' ' + o.perihal + ' ' + o.id + ' ' + o.namaJenis).toLowerCase().indexOf(q) !== -1; });
  return ok_(Object.assign({ ringkas: ringkas }, halaman_(out, b)));
}
function getPengajuan_(b) {
  const s = requireSesi_(b.token, null);
  const p = pengajuanById_(String(b.id || ''));
  if (!bolehLihat_(s, p)) throw new Error('FORBIDDEN');
  const riwayat = tabel_('Log').filter(function (l) { return l.id_pengajuan === p.id; }).map(function (l) { return { waktu: l.waktu, email: l.email, aksi: l.aksi, detail: l.detail }; });
  return ok_({ surat: suratOut_(p, { detail: true }), riwayat: riwayat });
}
function fetchPdf_(b) {
  const s = requireSesi_(b.token, null);
  const p = pengajuanById_(String(b.id || ''));
  if (!bolehLihat_(s, p)) throw new Error('FORBIDDEN');
  const pratinjau = b.pratinjau === true || b.pratinjau === 'true';
  let fid;
  if (pratinjau) {
    if (s.role === 'USER') throw new Error('FORBIDDEN');
    fid = p.status === 'TERBIT' ? p.id_pdf : p.id_pdf_pratinjau;
  } else {
    if (p.status !== 'TERBIT') throw new Error('BELUM_TERBIT'); // DITOLAK/DIBATALKAN tidak dapat diunduh
    fid = p.id_pdf;
  }
  if (!fid) throw new Error('PDF_BELUM_ADA');
  const blob = DriveApp.getFileById(fid).getBlob();
  if (!pratinjau) catat_(s.email, 'unduh', p.id, p.nomor_surat);
  return ok_({ nama: blob.getName(), mime: 'application/pdf', base64: Utilities.base64Encode(blob.getBytes()) });
}

function fetchLampiranPengajuan_(b) {
  const s = requireSesi_(b.token, null);
  const p = pengajuanById_(String(b.id || ''));
  if (!bolehLihat_(s, p)) throw new Error('FORBIDDEN');
  if (!p.id_lampiran) throw new Error('LAMPIRAN_TIDAK_ADA');
  const blob = DriveApp.getFileById(p.id_lampiran).getBlob();
  return ok_({ nama: blob.getName(), mime: blob.getContentType(), base64: Utilities.base64Encode(blob.getBytes()) });
}

// ---------- Admin ----------
function admins_() {
  const a = daftarProp_('ADMIN_EMAILS');
  tabelC_('Pengguna').forEach(function (u) { if (String(u.role).toUpperCase() === 'ADMIN' && String(u.status).toUpperCase() === 'AKTIF' && a.indexOf(normEmail_(u.email)) === -1) a.push(normEmail_(u.email)); });
  return a;
}
function listAntreanKelola_(b) {
  requireSesi_(b.token, ['ADMIN']);
  const q = String(b.q || '').toLowerCase();
  const semua = tabel_('Pengajuan');
  const hitung = { SEMUA: semua.length };
  STATUS_SURAT.forEach(function (st) { hitung[st] = 0; });
  semua.forEach(function (p) { hitung[p.status] = (hitung[p.status] || 0) + 1; });
  let rows = semua.filter(function (p) { return !b.status || b.status === 'SEMUA' || p.status === b.status; })
    .sort(function (x, y) { return x.tanggal < y.tanggal ? 1 : -1; });
  let out = rows.map(function (p) { return suratOut_(p); });
  if (q) out = out.filter(function (o) { return (o.nomor + ' ' + o.perihal + ' ' + o.id + ' ' + o.pemohon.nama + ' ' + o.pemohon.unit).toLowerCase().indexOf(q) !== -1; });
  return ok_(Object.assign({ hitung: hitung }, halaman_(out, b)));
}
function simpanPerbaikan_(b) {
  const s = requireSesi_(b.token, ['ADMIN']);
  return denganLock_(function () {
    const p = pengajuanById_(String(b.id || ''));
    if (['DIAJUKAN', 'DIPROSES'].indexOf(p.status) === -1) throw new Error('STATUS_TIDAK_VALID');
    const tpl = templateByKode_(p.jenis);
    const patch = { status: 'DIPROSES' };
    if (b.data) patch.data = JSON.stringify(validasiIsian_(parseIsian_(tpl.isian), b.data));
    if (b.pejabatEmail) { if (!pejabatByEmail_(b.pejabatEmail)) throw new Error('PEJABAT_TIDAK_ADA'); patch.pejabat_email = normEmail_(b.pejabatEmail); }
    if (b.tglSurat && /^\d{4}-\d{2}-\d{2}$/.test(b.tglSurat)) patch.tgl_surat = b.tglSurat;
    if (b.catatanAdmin !== undefined) patch.catatan_admin = bersih_(b.catatanAdmin, 500);
    ubahBaris_('Pengajuan', p._r, patch);
    catat_(s.email, 'proses', p.id, 'simpan perbaikan');
    bump('global');
    return ok_({ pesan: 'Perubahan disimpan' });
  });
}
function prosesDanNomori_(b) {
  const s = requireSesi_(b.token, ['ADMIN']);
  const id = String(b.id || '');
  // Tahap 1 (dalam lock): validasi, simpan perbaikan, beri nomor. TIDAK ada pembuatan PDF/email di sini.
  const tahap1 = denganLock_(function () {
    const p = pengajuanById_(id);
    if (['DIAJUKAN', 'DIPROSES'].indexOf(p.status) === -1) throw new Error('STATUS_TIDAK_VALID');
    const tpl = templateByKode_(p.jenis);
    const patch = { status: 'DIPROSES' };
    if (b.data) patch.data = JSON.stringify(validasiIsian_(parseIsian_(tpl.isian), b.data));
    const pejEmail = normEmail_(b.pejabatEmail || p.pejabat_email || tpl.pejabat_email);
    if (!pejEmail || !pejabatByEmail_(pejEmail)) throw new Error('PEJABAT_BELUM_DIATUR');
    if (!pimpinanBolehJenis_(pejEmail, p.jenis)) throw new Error('PEJABAT_TIDAK_BERWENANG_UNTUK_JENIS_INI');
    patch.pejabat_email = pejEmail;
    if (b.tglSurat && /^\d{4}-\d{2}-\d{2}$/.test(b.tglSurat)) patch.tgl_surat = b.tglSurat;
    if (b.catatanAdmin !== undefined) patch.catatan_admin = bersih_(b.catatanAdmin, 500);
    if (!p.nomor_surat) { // idempoten: jika sudah bernomor (retry PDF) jangan beri nomor baru
      const now = new Date();
      const no = naikkanNomor_(tpl.kode, tpl.reset_nomor, tpl.mulai_nomor, now);
      patch.nomor_surat = formatNomor_(tpl.format_nomor, no, tpl.kode, now);
      patch.status_nomor = 'AKTIF';
    }
    ubahBaris_('Pengajuan', p._r, patch);
    catat_(s.email, 'proses', p.id, 'nomor ' + (patch.nomor_surat || p.nomor_surat));
    return { r: p._r, nomor: patch.nomor_surat || p.nomor_surat, tplKode: tpl.kode };
  });
  // Tahap 2 (di luar lock): buat PDF pratinjau lalu kirim ke antrean pimpinan
  const p2 = pengajuanById_(id), tpl2 = templateByKode_(p2.jenis);
  const pej = pejabatByEmail_(p2.pejabat_email);
  let data = {};
  try { data = JSON.parse(p2.data || '{}'); } catch (e) { data = {}; }
  const pdfId = buatPdf_(p2, tpl2, data, { final: false, pejabat: pej, tanggalTerbit: p2.tgl_surat });
  if (p2.id_pdf_pratinjau) { try { DriveApp.getFileById(p2.id_pdf_pratinjau).setTrashed(true); } catch (e) { /* abaikan */ } }
  ubahBaris_('Pengajuan', tahap1.r, { id_pdf_pratinjau: pdfId, status: 'MENUNGGU_VERIFIKASI' });
  bump('global');
  notif_(p2.pejabat_email, 'Surat menunggu verifikasi Anda', 'Surat ' + tahap1.nomor + ' menunggu verifikasi dan tanda tangan Anda di aplikasi Persuratan.');
  return ok_({ nomor: tahap1.nomor, pesan: 'Nomor diberikan dan surat dikirim ke pimpinan' });
}
function tandaiNomorBatal_(p) { return p.nomor_surat ? { status_nomor: 'BATAL' } : {}; }
function tolakAdmin_(b) {
  const s = requireSesi_(b.token, ['ADMIN']);
  const alasan = bersih_(b.alasan, 500);
  if (!alasan) throw new Error('ALASAN_WAJIB');
  return denganLock_(function () {
    const p = pengajuanById_(String(b.id || ''));
    if (['DIAJUKAN', 'DIPROSES', 'MENUNGGU_VERIFIKASI'].indexOf(p.status) === -1) throw new Error('STATUS_TIDAK_VALID');
    ubahBaris_('Pengajuan', p._r, Object.assign({ status: 'DITOLAK', catatan_penolakan: alasan }, tandaiNomorBatal_(p)));
    catat_(s.email, 'tolak', p.id, alasan + (p.nomor_surat ? ' | nomor ' + p.nomor_surat + ' BATAL' : ''));
    bump('global');
    notif_(p.email_pemohon, 'Pengajuan surat ditolak', 'Pengajuan ' + p.id + ' ditolak. Alasan: ' + alasan);
    return ok_({ pesan: 'Pengajuan ditolak' });
  });
}
function batalkanSurat_(b) {
  const s = requireSesi_(b.token, ['ADMIN']);
  const alasan = bersih_(b.alasan, 500);
  if (!alasan) throw new Error('ALASAN_WAJIB');
  return denganLock_(function () {
    const p = pengajuanById_(String(b.id || ''));
    if (p.status !== 'TERBIT') throw new Error('HANYA_SURAT_TERBIT_YANG_DAPAT_DIBATALKAN');
    ubahBaris_('Pengajuan', p._r, { status: 'DIBATALKAN', catatan_penolakan: alasan, status_nomor: 'BATAL' });
    catat_(s.email, 'batal', p.id, alasan + ' | nomor ' + p.nomor_surat + ' BATAL');
    bump('global');
    notif_(p.email_pemohon, 'Surat dibatalkan', 'Surat ' + p.nomor_surat + ' dibatalkan. Alasan: ' + alasan);
    return ok_({ pesan: 'Surat dibatalkan' });
  });
}
function listNomor_(b) {
  requireSesi_(b.token, ['ADMIN']);
  const counter = tabel_('Nomor').map(function (n) { return { jenis: n.jenis, periode: n.periode, terakhir: Number(n.terakhir) }; });
  const daftar = tabel_('Pengajuan').filter(function (p) { return !!p.nomor_surat; }).sort(function (x, y) { return x.tanggal < y.tanggal ? 1 : -1; })
    .map(function (p) { return { id: p.id, nomor: p.nomor_surat, jenis: p.jenis, status: p.status, statusNomor: p.status_nomor || 'AKTIF', tanggal: p.tanggal }; });
  return ok_(Object.assign({ counter: counter, pola: previewNomorSemua_() }, halaman_(daftar, b)));
}

// ---------- Pimpinan ----------
function listAntreanVerifikasi_(b) {
  const s = requireSesi_(b.token, ['PIMPINAN']);
  const rows = tabel_('Pengajuan').filter(function (p) { return p.status === 'MENUNGGU_VERIFIKASI' && pimpinanBolehJenis_(s.email, p.jenis); })
    .sort(function (x, y) { return x.tanggal < y.tanggal ? -1 : 1; });
  return ok_({ rows: rows.map(function (p) { return suratOut_(p, { detail: true }); }) });
}
function setujuiTTE_(b) {
  const s = requireSesi_(b.token, ['PIMPINAN']);
  const id = String(b.id || ''), cache = CacheService.getScriptCache();
  denganLock_(function () { // cegah klik ganda: tandai sedang diproses
    const p = pengajuanById_(id);
    if (p.status !== 'MENUNGGU_VERIFIKASI') throw new Error('STATUS_TIDAK_VALID');
    if (!pimpinanBolehJenis_(s.email, p.jenis)) throw new Error('JENIS_DI_LUAR_WEWENANG');
    if (cache.get('tte_' + id)) throw new Error('SEDANG_DIPROSES');
    cache.put('tte_' + id, '1', 120);
  });
  try {
    const p = pengajuanById_(id), tpl = templateByKode_(p.jenis), pej = pejabatByEmail_(s.email);
    if (!pej || !pej.id_ttd) throw new Error('TTD_PEJABAT_BELUM_DIUNGGAH');
    let data = {};
    try { data = JSON.parse(p.data || '{}'); } catch (e) { data = {}; }
    const tglTerbit = sekarang_(), kode = hmacKode_(p.id, p.nomor_surat, p.jenis, tglTerbit);
    const base = prop_('FRONTEND_URL');
    if (!base) throw new Error('FRONTEND_URL_BELUM_DIISI');
    const qr = qrBlob_(base.replace(/[?#].*$/, '') + '?cek=' + encodeURIComponent(p.id) + '&k=' + kode);
    const pdfId = buatPdf_(p, tpl, data, { final: true, pejabat: pej, kode: kode, qr: qr, tanggalTerbit: hariIni_() });
    denganLock_(function () {
      const cur = pengajuanById_(id);
      if (cur.status !== 'MENUNGGU_VERIFIKASI') throw new Error('STATUS_TIDAK_VALID');
      ubahBaris_('Pengajuan', cur._r, { status: 'TERBIT', id_pdf: pdfId, kode_verif: kode, email_pemverifikasi: s.email, waktu_verifikasi: tglTerbit, tanggal_terbit: tglTerbit });
      catat_(s.email, 'verifikasi', id, 'terbit ' + cur.nomor_surat);
    });
    if (p.id_pdf_pratinjau) { try { DriveApp.getFileById(p.id_pdf_pratinjau).setTrashed(true); } catch (e) { /* abaikan */ } }
    bump('global');
    notif_(p.email_pemohon, 'Surat Anda telah terbit', 'Surat ' + p.nomor_surat + ' telah disetujui dan dapat diunduh dari Riwayat Pengajuan.');
    return ok_({ nomor: p.nomor_surat, pesan: 'Surat disetujui dan diterbitkan' });
  } finally {
    cache.remove('tte_' + id);
  }
}
function tolakPimpinan_(b) {
  const s = requireSesi_(b.token, ['PIMPINAN']);
  const catatan = bersih_(b.catatan, 500);
  if (!catatan) throw new Error('ALASAN_WAJIB');
  return denganLock_(function () {
    const p = pengajuanById_(String(b.id || ''));
    if (p.status !== 'MENUNGGU_VERIFIKASI') throw new Error('STATUS_TIDAK_VALID');
    if (!pimpinanBolehJenis_(s.email, p.jenis)) throw new Error('JENIS_DI_LUAR_WEWENANG');
    ubahBaris_('Pengajuan', p._r, Object.assign({ status: 'DITOLAK', catatan_penolakan: catatan, email_pemverifikasi: s.email, waktu_verifikasi: sekarang_() }, tandaiNomorBatal_(p)));
    catat_(s.email, 'tolak', p.id, catatan + ' | nomor ' + p.nomor_surat + ' BATAL');
    bump('global');
    notif_(p.email_pemohon, 'Surat ditolak pimpinan', 'Pengajuan ' + p.id + ' ditolak. Catatan: ' + catatan);
    return ok_({ pesan: 'Surat ditolak dengan catatan' });
  });
}

// ---------- Notifikasi email (opsional, diantrekan, dikirim di luar lock) ----------
function notif_(to, subjek, isi) {
  try {
    if (prop_('NOTIF_EMAIL_AKTIF', 'true') !== 'true' || !to || String(to).indexOf('@') === -1) return;
    const c = CacheService.getScriptCache(), q = JSON.parse(c.get('nq') || '[]');
    if (q.length < 200) { q.push({ t: String(to), s: String(subjek).slice(0, 120), b: String(isi).slice(0, 800) }); c.put('nq', JSON.stringify(q), 21600); }
  } catch (e) { /* notifikasi tidak boleh menggagalkan aksi */ }
}
function kirimNotifTerjadwal() {
  const c = CacheService.getScriptCache(), q = JSON.parse(c.get('nq') || '[]');
  if (!q.length) return;
  c.remove('nq');
  const nama = prop_('NAMA_ORG', 'Sistem Persuratan');
  q.slice(0, 40).forEach(function (m) {
    try { MailApp.sendEmail({ to: m.t, subject: '[' + nama + '] ' + m.s, body: m.b + '\n\n— Sistem Persuratan ' + nama }); } catch (e) { queueLog('-', 'MAIL', 'GAGAL', String(e), m.t); }
  });
}

// ============================================================
// 10. BOOT, DASHBOARD, LAPORAN, ARSIP, LOG
// ============================================================
function menuPeran_(role) {
  const m = [{ g: 'MENU', i: [['dashboard', 'Dashboard'], ['ajukan', 'Ajukan Surat'], ['riwayat', 'Riwayat Pengajuan']] }];
  if (role === 'ADMIN') m.push({ g: 'PERSURATAN', i: [['kelola', 'Kelola Surat'], ['suratmasuk', 'Surat Masuk'], ['arsip', 'Arsip'], ['template', 'Template'], ['nomor', 'Nomor Surat'], ['laporan', 'Laporan & Rekap']] });
  if (role === 'PIMPINAN') m.push({ g: 'PIMPINAN', i: [['verifikasi', 'Verifikasi Surat'], ['suratmasuk', 'Surat Masuk'], ['arsip', 'Arsip'], ['laporan', 'Laporan & Rekap']] });
  if (role === 'USER') m.push({ g: 'PERSURATAN', i: [['arsip', 'Arsip']] });
  if (role === 'ADMIN') m.push({ g: 'PENGATURAN', i: [['pengguna', 'Kelola Pengguna'], ['instansi', 'Instansi'], ['log', 'Log Aktivitas']] });
  m.push({ g: 'LAINNYA', i: [['bantuan', 'Bantuan'], ['cek', 'Cek Keaslian Surat']] });
  return m;
}
function bootData(token) {
  const s = requireSesi_(token, null, { bolehWajibGanti: true });
  const wajib = !!(verifyToken_(token) || {}).wajibGanti;
  const profil = { email: s.email, nama: s.nama, role: s.role, unit: s.unit, wajibGanti: wajib, darurat: !!s.darurat, namaOrg: prop_('NAMA_ORG', 'Organisasi') };
  if (wajib) return ok_({ data: { profil: profil, menu: [] } });
  const key = bootKey_(s.email), hit = CacheX.get(key);
  if (hit) return { success: true, data: hit, cached: true };
  const tpl = tabelC_('Template').filter(function (t) { return bool_(t.aktif) && (s.role !== 'USER' || bool_(t.boleh_pemohon)); }).map(function (t) { return templateOut_(t, false); });
  const data = { profil: profil, menu: menuPeran_(s.role), jenis: tpl, dashboard: dashboardData_(s) };
  CacheX.put(key, data, 120);
  return ok_({ data: data });
}
function getDashboard_(b) { const s = requireSesi_(b.token, null); return ok_({ data: dashboardData_(s, b.tahun) }); }

function bulanKe_(iso) { return parseInt(String(iso).slice(5, 7), 10); }
function dashboardData_(s, tahun) {
  tahun = String(tahun || Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyy'));
  let rows = tabel_('Pengajuan');
  if (s.role === 'USER') rows = rows.filter(function (p) { return normEmail_(p.email_pemohon) === s.email; });
  else if (s.role === 'PIMPINAN') rows = rows.filter(function (p) { return pimpinanBolehJenis_(s.email, p.jenis); });
  const now = new Date(), ymNow = Utilities.formatDate(now, 'Asia/Jakarta', 'yyyy-MM');
  const prev = new Date(now.getFullYear(), now.getMonth() - 1, 1), ymPrev = Utilities.formatDate(prev, 'Asia/Jakarta', 'yyyy-MM');
  const delta = function (fn) {
    const a = rows.filter(function (p) { return fn(p) && String(p.tanggal).slice(0, 7) === ymNow; }).length;
    const b2 = rows.filter(function (p) { return fn(p) && String(p.tanggal).slice(0, 7) === ymPrev; }).length;
    return b2 === 0 ? (a > 0 ? 100 : 0) : Math.round((a - b2) * 1000 / b2) / 10;
  };
  const hit = function (fn) { return rows.filter(fn).length; };
  const stat = s.role === 'USER'
    ? [{ k: 'Pengajuan Saya', n: rows.length, d: delta(function () { return true; }), s: 'semua jenis' },
       { k: 'Diproses', n: hit(function (p) { return ['DIAJUKAN', 'DIPROSES', 'MENUNGGU_VERIFIKASI'].indexOf(p.status) > -1; }), s: 'menunggu proses' },
       { k: 'Terbit', n: hit(function (p) { return p.status === 'TERBIT'; }), s: 'siap diunduh' },
       { k: 'Ditolak', n: hit(function (p) { return p.status === 'DITOLAK' || p.status === 'DIBATALKAN'; }), s: 'periksa catatan' }]
    : [{ k: 'Total Surat', n: rows.length, d: delta(function () { return true; }), s: 'semua pengajuan' },
       { k: 'Menunggu Diproses', n: hit(function (p) { return p.status === 'DIAJUKAN' || p.status === 'DIPROSES'; }), d: delta(function (p) { return p.status === 'DIAJUKAN' || p.status === 'DIPROSES'; }), s: 'perlu penomoran admin' },
       { k: 'Menunggu Verifikasi', n: hit(function (p) { return p.status === 'MENUNGGU_VERIFIKASI'; }), s: 'antrean TTD pimpinan' },
       { k: 'Surat Terbit', n: hit(function (p) { return p.status === 'TERBIT'; }), d: delta(function (p) { return p.status === 'TERBIT'; }), s: 'siap unduh & ber-QR' }];
  const diajukan = [], terbit = [];
  for (let i = 0; i < 12; i++) { diajukan.push(0); terbit.push(0); }
  rows.forEach(function (p) {
    if (String(p.tanggal).slice(0, 4) === tahun) diajukan[bulanKe_(p.tanggal) - 1]++;
    if (p.status === 'TERBIT' && String(p.tanggal_terbit).slice(0, 4) === tahun) terbit[bulanKe_(p.tanggal_terbit) - 1]++;
  });
  const namaJenis = {};
  tabelC_('Template').forEach(function (t) { namaJenis[t.kode] = t.nama; });
  const per = {};
  rows.forEach(function (p) { per[p.jenis] = (per[p.jenis] || 0) + 1; });
  const perJenis = Object.keys(per).map(function (k) { return { kode: k, nama: namaJenis[k] || k, n: per[k] }; }).sort(function (a, c) { return c.n - a.n; });
  const out = { tahun: tahun, stat: stat, grafik: { diajukan: diajukan, terbit: terbit }, perJenis: perJenis, efisiensi: rows.length ? Math.round(hit(function (p) { return p.status === 'TERBIT'; }) * 1000 / rows.length) / 10 : 0 };
  if (s.role === 'PIMPINAN') {
    out.antrean = rows.filter(function (p) { return p.status === 'MENUNGGU_VERIFIKASI'; }).slice(0, 4).map(function (p) { return suratOut_(p); });
    out.jumlahAntrean = hit(function (p) { return p.status === 'MENUNGGU_VERIFIKASI'; });
  } else if (s.role === 'ADMIN') {
    const u = {};
    rows.forEach(function (p) {
      const pem = tabelC_('Pengguna').filter(function (x) { return normEmail_(x.email) === normEmail_(p.email_pemohon); })[0];
      const k = (pem && pem.unit) || 'Tanpa unit'; u[k] = (u[k] || 0) + 1;
    });
    out.asal = Object.keys(u).map(function (k) { return { unit: k, n: u[k] }; }).sort(function (a, c) { return c.n - a.n; }).slice(0, 5);
    out.notif = out.stat[1].n + out.stat[2].n;
  }
  if (s.role === 'USER') out.notif = out.stat[3].n;
  return out;
}

function getLaporan_(b) {
  const s = requireSesi_(b.token, ['ADMIN', 'PIMPINAN']);
  let rows = tabel_('Pengajuan');
  if (s.role === 'PIMPINAN') rows = rows.filter(function (p) { return pimpinanBolehJenis_(s.email, p.jenis); });
  const dari = String(b.dari || '0000-00-00'), sampai = String(b.sampai || '9999-99-99');
  rows = rows.filter(function (p) {
    const t = String(p.tanggal).slice(0, 10);
    if (t < dari || t > sampai) return false;
    if (b.jenis && p.jenis !== b.jenis) return false;
    if (b.status && p.status !== b.status) return false;
    return true;
  });
  const unitDari = function (p) { const u = tabelC_('Pengguna').filter(function (x) { return normEmail_(x.email) === normEmail_(p.email_pemohon); })[0]; return (u && u.unit) || ''; };
  if (b.unit) rows = rows.filter(function (p) { return unitDari(p).toLowerCase().indexOf(String(b.unit).toLowerCase()) !== -1; });
  const terbit = rows.filter(function (p) { return p.status === 'TERBIT'; });
  const ditolak = rows.filter(function (p) { return p.status === 'DITOLAK' || p.status === 'DIBATALKAN'; });
  let jam = 0, nj = 0;
  terbit.forEach(function (p) { const d = (new Date(p.tanggal_terbit) - new Date(p.tanggal)) / 3600000; if (d >= 0) { jam += d; nj++; } });
  const diajukan = [], tr = [];
  for (let i = 0; i < 12; i++) { diajukan.push(0); tr.push(0); }
  rows.forEach(function (p) { diajukan[bulanKe_(p.tanggal) - 1]++; if (p.status === 'TERBIT') tr[bulanKe_(p.tanggal_terbit) - 1]++; });
  const namaJenis = {}; tabelC_('Template').forEach(function (t) { namaJenis[t.kode] = t.nama; });
  const per = {}; rows.forEach(function (p) { per[p.jenis] = (per[p.jenis] || 0) + 1; });
  const urut = rows.sort(function (x, y) { return x.tanggal < y.tanggal ? 1 : -1; });
  const mapRow = function (p) {
    const o = suratOut_(p), pj = pejabatByEmail_(p.pejabat_email) || {};
    return { id: p.id, nomor: p.nomor_surat, jenis: o.namaJenis, unit: unitDari(p), perihal: o.perihal, tanggal: p.tanggal, status: p.status, pejabat: pj.nama || '', tanggalTerbit: p.tanggal_terbit };
  };
  const hasil = {
    kpi: { total: rows.length, terbit: terbit.length, rasioTerbit: rows.length ? Math.round(terbit.length * 1000 / rows.length) / 10 : 0, rataJam: nj ? Math.round(jam / nj * 10) / 10 : 0, ditolak: ditolak.length, rasioDitolak: rows.length ? Math.round(ditolak.length * 1000 / rows.length) / 10 : 0 },
    grafik: { diajukan: diajukan, terbit: tr },
    perJenis: Object.keys(per).map(function (k) { return { nama: namaJenis[k] || k, n: per[k] }; }).sort(function (a, c) { return c.n - a.n; })
  };
  if (b.semua) { hasil.rows = urut.slice(0, 5000).map(mapRow); return ok_(hasil); }
  return ok_(Object.assign(hasil, halaman_(urut.map(mapRow), b)));
}

function listArsip_(b) {
  const s = requireSesi_(b.token, null);
  const q = String(b.q || '').toLowerCase(), out = [];
  const nj = {}; tabelC_('Template').forEach(function (t) { nj[t.kode] = t.nama; });
  if (!b.arah || b.arah === 'KELUAR') {
    tabel_('Pengajuan').filter(function (p) { return p.status === 'TERBIT' && bolehLihat_(s, p); }).forEach(function (p) {
      const o = suratOut_(p);
      out.push({ tipe: 'KELUAR', id: p.id, nomor: p.nomor_surat, jenis: o.namaJenis, jenisKode: p.jenis, perihal: o.perihal, pihak: o.pemohon.unit || o.pemohon.nama, tanggal: (p.tanggal_terbit || p.tanggal).slice(0, 10), status: p.status });
    });
  }
  if ((!b.arah || b.arah === 'MASUK') && s.role !== 'USER') {
    const ins = {}; tabelC_('Instansi').forEach(function (i) { ins[i.id] = i.nama; });
    tabel_('SuratMasuk').forEach(function (m) {
      out.push({ tipe: 'MASUK', id: m.id, nomor: m.no_agenda + ' / ' + m.no_surat_asal, jenis: 'Surat Masuk', jenisKode: 'MASUK', perihal: m.perihal, pihak: ins[m.instansi_id] || '', instansiId: m.instansi_id, tanggal: m.tgl_terima, status: m.status });
    });
  }
  let rows = out.filter(function (o) {
    if (b.jenis && o.jenisKode !== b.jenis) return false;
    if (b.tahun && String(o.tanggal).slice(0, 4) !== String(b.tahun)) return false;
    if (b.instansiId && o.instansiId !== b.instansiId) return false;
    if (q && (o.nomor + ' ' + o.perihal + ' ' + o.pihak + ' ' + o.jenis).toLowerCase().indexOf(q) === -1) return false;
    return true;
  }).sort(function (x, y) { return x.tanggal < y.tanggal ? 1 : -1; });
  return ok_(halaman_(rows, b));
}

function listLog_(b) {
  requireSesi_(b.token, ['ADMIN']);
  const sh = sheet_('Log'), last = sh.getLastRow();
  if (last < 2) return ok_(halaman_([], b));
  const mulai = Math.max(2, last - 1999), v = sh.getRange(mulai, 1, last - mulai + 1, 5).getValues();
  const q = String(b.q || '').toLowerCase();
  let rows = v.map(function (r) { return { waktu: String(r[0]), email: String(r[1]), aksi: String(r[2]), id: String(r[3]), detail: String(r[4]) }; }).reverse();
  rows = rows.filter(function (r) { return (!b.aksi || r.aksi === b.aksi) && (!q || (r.email + ' ' + r.id + ' ' + r.detail + ' ' + r.aksi).toLowerCase().indexOf(q) !== -1); });
  return ok_(halaman_(rows, b));
}

// ============================================================
// 11. VERIFIKASI KEASLIAN PUBLIK (QR) — data minimum
// ============================================================
function getVerifikasiPublik_(id, k) {
  id = String(id || '').slice(0, 40); k = String(k || '').slice(0, 40);
  if (!id || !k) return ok_({ ditemukan: false });
  const cache = CacheService.getScriptCache(), ck = 'vp_' + id;
  const n = Number(cache.get(ck + '_n') || 0);
  if (n > 30) throw new Error('TERLALU_BANYAK_PERMINTAAN');
  cache.put(ck + '_n', String(n + 1), 300);
  const p = tabel_('Pengajuan').filter(function (x) { return x.id === id; })[0];
  if (!p || !p.kode_verif) return ok_({ ditemukan: false });
  const hitung = hmacKode_(p.id, p.nomor_surat, p.jenis, p.tanggal_terbit);
  const cocok = samaAman_(hitung, p.kode_verif) && samaAman_(k, p.kode_verif);
  const tpl = tabelC_('Template').filter(function (t) { return t.kode === p.jenis; })[0];
  if (!cocok) return ok_({ ditemukan: true, sah: false });
  return ok_({ ditemukan: true, sah: p.status === 'TERBIT', status: p.status, nomor: p.nomor_surat, jenis: tpl ? tpl.nama : p.jenis, tanggalTerbit: p.tanggal_terbit.slice(0, 10), namaOrg: prop_('NAMA_ORG', 'Organisasi') });
}

// ============================================================
// 12. SURAT MASUK (pencatatan, disposisi sederhana)
// ============================================================
function suratMasukOut_(m, ins) {
  return { id: m.id, noAgenda: m.no_agenda, noSuratAsal: m.no_surat_asal, tglSurat: m.tgl_surat, tglTerima: m.tgl_terima, instansiId: m.instansi_id, instansi: (ins && ins[m.instansi_id]) || '', perihal: m.perihal, sifat: m.sifat, status: m.status, tujuan: m.tujuan_disposisi, catatan: m.catatan_disposisi, adaLampiran: !!m.id_lampiran, dicatatOleh: m.dicatat_oleh, dicatatPada: m.dicatat_pada };
}
function listSuratMasuk_(b) {
  requireSesi_(b.token, ['ADMIN', 'PIMPINAN']);
  const ins = {}; tabelC_('Instansi').forEach(function (i) { ins[i.id] = i.nama; });
  const q = String(b.q || '').toLowerCase(), semua = tabel_('SuratMasuk');
  const hitung = { SEMUA: semua.length, DITERIMA: 0, DIDISPOSISIKAN: 0, SELESAI: 0 };
  semua.forEach(function (m) { hitung[m.status] = (hitung[m.status] || 0) + 1; });
  const rows = semua.filter(function (m) {
    if (b.status && b.status !== 'SEMUA' && m.status !== b.status) return false;
    if (q && (m.no_agenda + ' ' + m.no_surat_asal + ' ' + m.perihal + ' ' + (ins[m.instansi_id] || '')).toLowerCase().indexOf(q) === -1) return false;
    return true;
  }).sort(function (x, y) { return x.dicatat_pada < y.dicatat_pada ? 1 : -1; }).map(function (m) { return suratMasukOut_(m, ins); });
  return ok_(Object.assign({ hitung: hitung }, halaman_(rows, b)));
}
function catatSuratMasuk_(b) {
  const s = requireSesi_(b.token, ['ADMIN']);
  const perihal = bersih_(b.perihal, 300), noAsal = bersih_(b.noSuratAsal, 100);
  if (!perihal || !noAsal) throw new Error('PERIHAL_DAN_NOMOR_ASAL_WAJIB');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(b.tglSurat)) || !/^\d{4}-\d{2}-\d{2}$/.test(String(b.tglTerima || hariIni_()))) throw new Error('TANGGAL_TIDAK_VALID');
  const ins = tabelC_('Instansi').filter(function (i) { return i.id === b.instansiId && bool_(i.aktif); })[0];
  if (!ins) throw new Error('INSTANSI_TIDAK_DITEMUKAN');
  const sifat = ['BIASA', 'PENTING', 'SEGERA'].indexOf(String(b.sifat)) > -1 ? b.sifat : 'BIASA';
  const idLamp = unggahBerkas_(b.lampiran, 'FOLDER_LAMPIRAN', 'masuk');
  return denganLock_(function () {
    const now = new Date(), no = naikkanNomor_('AGENDA', 'TAHUNAN', 1, now);
    const agenda = 'AG/' + pad_(no, 3) + '/' + periode_('TAHUNAN', now);
    const id = 'SM-' + periode_('TAHUNAN', now) + '-' + pad_(no, 4);
    tambahBaris_('SuratMasuk', { id: id, no_agenda: agenda, no_surat_asal: noAsal, tgl_surat: b.tglSurat, tgl_terima: b.tglTerima || hariIni_(), instansi_id: ins.id, perihal: perihal, sifat: sifat, id_lampiran: idLamp, status: 'DITERIMA', dicatat_oleh: s.email, dicatat_pada: sekarang_() });
    catat_(s.email, 'surat_masuk', id, 'catat ' + agenda);
    return ok_({ id: id, noAgenda: agenda, pesan: 'Surat masuk dicatat' });
  });
}
function disposisiSuratMasuk_(b) {
  const s = requireSesi_(b.token, ['ADMIN', 'PIMPINAN']);
  const catatan = bersih_(b.catatan, 500);
  return denganLock_(function () {
    const m = tabel_('SuratMasuk').filter(function (x) { return x.id === b.id; })[0];
    if (!m) throw new Error('TIDAK_DITEMUKAN');
    if (m.status === 'SELESAI') throw new Error('STATUS_TIDAK_VALID');
    const patch = { status: 'DIDISPOSISIKAN' };
    if (s.role === 'ADMIN') {
      const tujuan = bersih_(b.tujuan, 150);
      if (!tujuan) throw new Error('TUJUAN_WAJIB');
      patch.tujuan_disposisi = tujuan;
      patch.catatan_disposisi = catatan;
    } else {
      if (!catatan) throw new Error('CATATAN_WAJIB');
      patch.catatan_disposisi = (m.catatan_disposisi ? m.catatan_disposisi + ' | ' : '') + (s.nama || s.email) + ': ' + catatan;
    }
    ubahBaris_('SuratMasuk', m._r, patch);
    catat_(s.email, 'surat_masuk', m.id, 'disposisi');
    return ok_({ pesan: 'Disposisi disimpan' });
  });
}
function selesaiSuratMasuk_(b) {
  const s = requireSesi_(b.token, ['ADMIN']);
  return denganLock_(function () {
    const m = tabel_('SuratMasuk').filter(function (x) { return x.id === b.id; })[0];
    if (!m) throw new Error('TIDAK_DITEMUKAN');
    ubahBaris_('SuratMasuk', m._r, { status: 'SELESAI' });
    catat_(s.email, 'surat_masuk', m.id, 'selesai');
    return ok_({ pesan: 'Surat masuk ditandai selesai' });
  });
}
function fetchLampiranMasuk_(b) {
  requireSesi_(b.token, ['ADMIN', 'PIMPINAN']);
  const m = tabel_('SuratMasuk').filter(function (x) { return x.id === b.id; })[0];
  if (!m || !m.id_lampiran) throw new Error('LAMPIRAN_TIDAK_ADA');
  const blob = DriveApp.getFileById(m.id_lampiran).getBlob();
  return ok_({ nama: blob.getName(), mime: blob.getContentType(), base64: Utilities.base64Encode(blob.getBytes()) });
}

// ============================================================
// 13. SETUP OTOMATIS (idempoten — aman dijalankan berulang)
// ============================================================
function setupAppEnvironment() {
  Logger.log('🚀 Memulai setup Sistem Persuratan...');
  if (!prop_('SPREADSHEET_ID')) {
    const root = DriveApp.createFolder('📁 Sistem Persuratan');
    const fTemplate = root.createFolder('📂 Template Kop Surat'), fTtd = root.createFolder('🔒 Tanda Tangan & Cap'), fArsip = root.createFolder('📂 Arsip Surat PDF'), fLamp = root.createFolder('📂 Lampiran');
    const ss = SpreadsheetApp.create('🗃️ Database — Sistem Persuratan');
    DriveApp.getFileById(ss.getId()).moveTo(root);
    Object.keys(KOLOM).forEach(function (nama, i) {
      const sh = i === 0 ? ss.getActiveSheet().setName(nama) : ss.insertSheet(nama);
      const h = KOLOM[nama];
      sh.getRange(1, 1, sh.getMaxRows(), h.length).setNumberFormat('@'); // semua teks polos (nomor, NIP, tanggal tidak berubah)
      sh.getRange(1, 1, 1, h.length).setValues([h]).setFontWeight('bold').setBackground('#E0E2FF');
      sh.setFrozenRows(1);
    });
    setProps_({ SPREADSHEET_ID: ss.getId(), ROOT_FOLDER_ID: root.getId(), FOLDER_TEMPLATE: fTemplate.getId(), FOLDER_TTD: fTtd.getId(), FOLDER_ARSIP: fArsip.getId(), FOLDER_LAMPIRAN: fLamp.getId() });
    Logger.log('✅ Spreadsheet dibuat: ' + ss.getUrl());
  } else {
    Logger.log('ℹ️ Struktur data sudah ada, dilewati (idempoten).');
  }
  // Isi properti konfigurasi hanya jika belum ada (tidak menimpa)
  const def = { MODE_AKSES: 'GMAIL', DAFTAR_MANDIRI: 'true', NOTIF_EMAIL_AKTIF: 'true', NAMA_ORG: 'Nama Organisasi Anda' };
  Object.keys(def).forEach(function (k) { if (!prop_(k)) setProp_(k, def[k]); });
  ['GOOGLE_CLIENT_ID', 'ADMIN_EMAILS', 'DOMAIN_IZIN', 'FRONTEND_URL'].forEach(function (k) { if (PROPS.getProperty(k) === null) setProp_(k, ''); });
  setupRahasia_();
  if (tabel_('Template').length === 0) buatContohTemplate_();
  Logger.log('✅ Setup selesai. Langkah berikut: isi GOOGLE_CLIENT_ID, ADMIN_EMAILS, DOMAIN_IZIN, FRONTEND_URL di Project Settings → Script Properties, lalu jalankan pasangTrigger().');
}

/** Membuat contoh template "Surat Tugas" lengkap dengan penanda, agar langsung bisa dicoba. */
function buatContohTemplate_() {
  const doc = DocumentApp.create('Master_Surat_Tugas (contoh)');
  const b = doc.getBody();
  b.appendParagraph('[GANTI DENGAN KOP SURAT ORGANISASI ANDA]').setAlignment(DocumentApp.HorizontalAlignment.CENTER).setBold(true);
  b.appendHorizontalRule();
  b.appendParagraph('SURAT TUGAS').setAlignment(DocumentApp.HorizontalAlignment.CENTER).setBold(true);
  b.appendParagraph('Nomor: {{nomor_surat}}').setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  b.appendParagraph('Yang bertanda tangan di bawah ini, {{jabatan_pejabat}}, memberikan penugasan kepada:');
  b.appendParagraph('Nama\t: {{nama_personel}}');
  b.appendParagraph('NIP\t: {{nama_personel_nip}}');
  b.appendParagraph('Jabatan\t: {{nama_personel_jabatan}}');
  b.appendParagraph('Untuk melaksanakan tugas: {{perihal}}');
  b.appendParagraph('Tempat\t: {{tempat_kegiatan}}');
  b.appendParagraph('Tanggal\t: {{tanggal_mulai}} s.d. {{tanggal_selesai}}');
  b.appendParagraph('Rincian\t: {{keperluan}}');
  b.appendParagraph('Demikian surat tugas ini dibuat untuk dilaksanakan dengan penuh tanggung jawab.');
  b.appendParagraph('Ditetapkan pada {{tanggal_terbit}}').setAlignment(DocumentApp.HorizontalAlignment.RIGHT);
  b.appendParagraph('{{jabatan_pejabat}}').setAlignment(DocumentApp.HorizontalAlignment.RIGHT);
  b.appendParagraph('{{cap}}{{ttd}}').setAlignment(DocumentApp.HorizontalAlignment.RIGHT);
  b.appendParagraph('{{nama_pejabat}}').setAlignment(DocumentApp.HorizontalAlignment.RIGHT).setBold(true);
  b.appendParagraph('NIP. {{nip_pejabat}}').setAlignment(DocumentApp.HorizontalAlignment.RIGHT);
  b.appendParagraph('{{qr}}');
  b.appendParagraph('Kode verifikasi: {{kode_verifikasi}} — pindai QR untuk memeriksa keaslian surat.');
  doc.saveAndClose();
  DriveApp.getFileById(doc.getId()).moveTo(DriveApp.getFolderById(prop_('FOLDER_TEMPLATE')));
  const isian = [
    { tag: 'nama_personel', label: 'Nama / Pihak yang Ditugaskan', tipe: 'personel', wajib: true, opsi: '', bantuan: 'Pilih dari data pengguna' },
    { tag: 'perihal', label: 'Perihal Surat', tipe: 'text', wajib: true, opsi: '', bantuan: 'Ringkasan singkat tugas' },
    { tag: 'tempat_kegiatan', label: 'Tujuan / Tempat Kegiatan', tipe: 'text', wajib: true, opsi: '', bantuan: '' },
    { tag: 'tanggal_mulai', label: 'Tanggal Mulai', tipe: 'date', wajib: true, opsi: '', bantuan: '' },
    { tag: 'tanggal_selesai', label: 'Tanggal Selesai', tipe: 'date', wajib: true, opsi: '', bantuan: '' },
    { tag: 'keperluan', label: 'Keperluan & Rincian Tugas', tipe: 'textarea', wajib: true, opsi: '', bantuan: '' }
  ];
  tambahBaris_('Template', { kode: 'ST', nama: 'Surat Tugas', id_docs: doc.getId(), isian: JSON.stringify(isian), format_nomor: '{no:000}/{kode}/{bulan_romawi}/{tahun}', reset_nomor: 'TAHUNAN', pejabat_email: '', boleh_pemohon: 'TRUE', aktif: 'TRUE', mulai_nomor: '1', deskripsi: 'Penugasan resmi dosen, staf, atau kegiatan.' });
  Logger.log('📄 Contoh template Surat Tugas dibuat: ' + doc.getUrl());
}
